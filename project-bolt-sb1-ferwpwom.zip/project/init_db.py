#!/usr/bin/env python3
"""
Database initialization script for Hisnak Marketplace
This script creates all database tables and optionally seeds initial data
"""

import sys
import os

# Add the src directory to the Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Import the Flask app directly
from main import app
from models.user import db, User, UserRole
from werkzeug.security import generate_password_hash
import uuid

def init_database():
    """Initialize the database with tables and optional seed data"""
    with app.app_context():
        # Create all tables
        print("Creating database tables...")
        db.create_all()
        print("Database tables created successfully!")
        
        # Check if admin user already exists
        admin_user = User.query.filter_by(email='admin@hisnak.com').first()
        
        if not admin_user:
            print("Creating default admin user...")
            
            # Create default admin user
            admin_user = User(
                username='admin',
                email='admin@hisnak.com',
                password_hash=generate_password_hash('admin123'),
                first_name='Admin',
                last_name='User',
                role=UserRole.ADMIN,
                is_active=True,
                is_verified=True
            )
            
            admin_user.generate_referral_code()
            
            db.session.add(admin_user)
            db.session.commit()
            
            print(f"Admin user created successfully!")
            print(f"Email: admin@hisnak.com")
            print(f"Password: admin123")
            print("Please change the default password after first login!")
        else:
            print("Admin user already exists.")
        
        print("Database initialization completed!")

if __name__ == '__main__':
    init_database()

