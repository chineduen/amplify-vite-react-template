# Hisnak Marketplace API Documentation

## Overview

The Hisnak Marketplace API is a RESTful API that provides comprehensive functionality for an affiliate marketing platform with multi-level commission tracking, payment processing, and user management.

**Base URL**: `https://your-domain.com/api`

## Authentication

Most endpoints require authentication using JWT tokens. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

### Getting a Token

```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "message": "Login successful",
  "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
  "user": {
    "id": "user-id",
    "username": "username",
    "email": "user@example.com",
    "role": "affiliate"
  }
}
```

## User Roles

- **Admin**: Full platform access, user management, product approval
- **Vendor**: Product creation and management, sales analytics
- **Affiliate**: Product promotion, commission tracking, referral management

## API Endpoints

### Authentication Endpoints

#### Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "newuser",
  "email": "newuser@example.com",
  "password": "password123",
  "first_name": "John",
  "last_name": "Doe",
  "role": "affiliate",
  "referrer_code": "optional-referrer-code"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}
```

#### Get Profile
```http
GET /api/auth/profile
Authorization: Bearer <token>
```

### Affiliate Endpoints

#### Get Dashboard
```http
GET /api/affiliate/dashboard
Authorization: Bearer <token>
```

**Response:**
```json
{
  "statistics": {
    "total_earnings": 15000.00,
    "level1_earnings": 12000.00,
    "level2_earnings": 3000.00,
    "current_balance": 8000.00,
    "active_links": 5,
    "total_clicks": 1250,
    "total_conversions": 45,
    "conversion_rate": 3.6,
    "direct_referrals": 8
  },
  "recent_commissions": [...],
  "referral_tree": {...}
}
```

#### Create Affiliate Link
```http
POST /api/affiliate/links
Authorization: Bearer <token>
Content-Type: application/json

{
  "product_id": "product-id",
  "custom_url": "optional-custom-url"
}
```

#### Get Commissions
```http
GET /api/affiliate/commissions?page=1&per_page=20&type=direct
Authorization: Bearer <token>
```

### Payment Endpoints

#### Initialize Payment
```http
POST /api/payment/initialize
Content-Type: application/json

{
  "product_id": "product-id",
  "customer_email": "customer@example.com",
  "customer_name": "Customer Name",
  "payment_method": "paystack",
  "affiliate_link_code": "optional-affiliate-code"
}
```

#### Add Bank Account
```http
POST /api/payment/bank-accounts
Authorization: Bearer <token>
Content-Type: application/json

{
  "account_name": "John Doe",
  "account_number": "1234567890",
  "bank_name": "Access Bank",
  "bank_code": "044",
  "bvn": "12345678901"
}
```

#### Request Withdrawal
```http
POST /api/payment/withdrawals
Authorization: Bearer <token>
Content-Type: application/json

{
  "amount": 5000.00,
  "bank_account_id": "bank-account-id",
  "reason": "Monthly withdrawal"
}
```

### Product Endpoints

#### Get Products
```http
GET /api/products?page=1&per_page=20&category=digital&search=course
```

**Query Parameters:**
- `page`: Page number (default: 1)
- `per_page`: Items per page (default: 20)
- `category`: Filter by category
- `search`: Search in name and description
- `featured`: Filter featured products (true/false)
- `min_price`: Minimum price filter
- `max_price`: Maximum price filter
- `type`: Product type (digital/physical)

#### Get Single Product
```http
GET /api/products/{product_id}
```

#### Create Product (Vendors Only)
```http
POST /api/products
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Digital Marketing Course",
  "description": "Complete digital marketing course...",
  "short_description": "Learn digital marketing from scratch",
  "price": 25000.00,
  "product_type": "digital",
  "category": "Education",
  "commission_percentage": 60.00,
  "download_url": "https://example.com/download",
  "tags": ["marketing", "digital", "course"]
}
```

### Admin Endpoints

#### Get Dashboard
```http
GET /api/admin/dashboard
Authorization: Bearer <token>
```

#### Approve Product
```http
POST /api/admin/products/{product_id}/approve
Authorization: Bearer <token>
```

#### Approve KYC Document
```http
POST /api/admin/kyc/{document_id}/approve
Authorization: Bearer <token>
```

#### Approve Withdrawal
```http
POST /api/admin/withdrawals/{withdrawal_id}/approve
Authorization: Bearer <token>
```

### Vendor Endpoints

#### Get Dashboard
```http
GET /api/vendor/dashboard
Authorization: Bearer <token>
```

#### Get Product Analytics
```http
GET /api/vendor/products/{product_id}/analytics?days=30
Authorization: Bearer <token>
```

#### Get Vendor Affiliates
```http
GET /api/vendor/affiliates?page=1&per_page=20
Authorization: Bearer <token>
```

## Webhook Endpoints

### Paystack Webhook
```http
POST /api/payment/paystack/webhook
X-Paystack-Signature: <signature>
Content-Type: application/json

{
  "event": "charge.success",
  "data": {
    "reference": "transaction-reference",
    "amount": 2500000,
    "currency": "NGN",
    "status": "success"
  }
}
```

### Flutterwave Webhook
```http
POST /api/payment/flutterwave/webhook
verif-hash: <signature>
Content-Type: application/json

{
  "event": "charge.completed",
  "data": {
    "tx_ref": "transaction-reference",
    "amount": 25000,
    "currency": "NGN",
    "status": "successful"
  }
}
```

## Error Responses

The API uses standard HTTP status codes and returns error details in JSON format:

```json
{
  "error": "Error message description"
}
```

### Common Status Codes

- `200 OK`: Request successful
- `201 Created`: Resource created successfully
- `400 Bad Request`: Invalid request data
- `401 Unauthorized`: Authentication required
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server error

## Rate Limiting

API requests are rate-limited to prevent abuse:
- **Authentication endpoints**: 5 requests per minute
- **General endpoints**: 100 requests per minute
- **Webhook endpoints**: No rate limiting

## Data Models

### User Model
```json
{
  "id": "user-id",
  "username": "username",
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe",
  "role": "affiliate",
  "is_active": true,
  "is_verified": false,
  "referral_code": "ABC123",
  "created_at": "2024-01-01T00:00:00Z"
}
```

### Product Model
```json
{
  "id": "product-id",
  "name": "Product Name",
  "description": "Product description",
  "price": 25000.00,
  "currency": "NGN",
  "product_type": "digital",
  "category": "Education",
  "commission_percentage": 60.00,
  "status": "approved",
  "is_active": true,
  "is_featured": false,
  "views_count": 150,
  "created_at": "2024-01-01T00:00:00Z"
}
```

### Commission Model
```json
{
  "id": "commission-id",
  "transaction_id": "transaction-id",
  "affiliate_id": "affiliate-id",
  "commission_type": "direct",
  "commission_level": 1,
  "amount": 15000.00,
  "percentage": 50.00,
  "status": "completed",
  "created_at": "2024-01-01T00:00:00Z"
}
```

### Transaction Model
```json
{
  "id": "transaction-id",
  "product_id": "product-id",
  "amount": 25000.00,
  "currency": "NGN",
  "payment_method": "paystack",
  "status": "completed",
  "customer_email": "customer@example.com",
  "customer_name": "Customer Name",
  "transaction_ref": "TXN_123456789",
  "created_at": "2024-01-01T00:00:00Z"
}
```

## Testing

### Test Credentials

**Admin User:**
- Email: `admin@hisnak.com`
- Password: `admin123`

### Test Payment Cards

**Paystack Test Cards:**
- Success: `4084084084084081`
- Decline: `4084084084084084`

**Flutterwave Test Cards:**
- Success: `5531886652142950`
- Decline: `5531886652142951`

## SDKs and Libraries

### JavaScript/Node.js
```javascript
const axios = require('axios');

const api = axios.create({
  baseURL: 'https://your-domain.com/api',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  }
});

// Get affiliate dashboard
const dashboard = await api.get('/affiliate/dashboard');
```

### Python
```python
import requests

headers = {
    'Content-Type': 'application/json',
    'Authorization': f'Bearer {token}'
}

# Get affiliate dashboard
response = requests.get(
    'https://your-domain.com/api/affiliate/dashboard',
    headers=headers
)
```

## Support

For API support:
- Email: api-support@hisnak.com
- Documentation: https://your-domain.com/api/docs
- Status Page: https://status.hisnak.com

