from flask import Blueprint, request, jsonify, current_app
from src.models.user import db, User, Product, Transaction, AffiliateLink, BankAccount, Withdrawal, TransactionStatus, WithdrawalStatus
from src.routes.auth import token_required, role_required
from src.routes.affiliate import calculate_commissions
from datetime import datetime, timezone
from decimal import Decimal
import requests
import json
import hmac
import hashlib
import uuid
import logging
import re

payment_bp = Blueprint('payment', __name__)
logger = logging.getLogger(__name__)

# Nigerian Banks List
NIGERIAN_BANKS = [
    {"name": "Access Bank", "code": "044"},
    {"name": "Citibank Nigeria", "code": "023"},
    {"name": "Diamond Bank", "code": "063"},
    {"name": "Ecobank Nigeria", "code": "050"},
    {"name": "Fidelity Bank", "code": "070"},
    {"name": "First Bank of Nigeria", "code": "011"},
    {"name": "First City Monument Bank", "code": "214"},
    {"name": "Guaranty Trust Bank", "code": "058"},
    {"name": "Heritage Bank", "code": "030"},
    {"name": "Keystone Bank", "code": "082"},
    {"name": "Polaris Bank", "code": "076"},
    {"name": "Providus Bank", "code": "101"},
    {"name": "Stanbic IBTC Bank", "code": "221"},
    {"name": "Standard Chartered Bank", "code": "068"},
    {"name": "Sterling Bank", "code": "232"},
    {"name": "Union Bank of Nigeria", "code": "032"},
    {"name": "United Bank For Africa", "code": "033"},
    {"name": "Unity Bank", "code": "215"},
    {"name": "Wema Bank", "code": "035"},
    {"name": "Zenith Bank", "code": "057"}
]

def verify_paystack_signature(payload, signature, secret):
    """Verify Paystack webhook signature"""
    computed_signature = hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha512
    ).hexdigest()
    return hmac.compare_digest(computed_signature, signature)

def verify_flutterwave_signature(payload, signature, secret):
    """Verify Flutterwave webhook signature"""
    computed_signature = hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(computed_signature, signature)

@payment_bp.route('/banks', methods=['GET'])
def get_banks():
    """Get list of Nigerian banks"""
    return jsonify({
        'banks': NIGERIAN_BANKS
    }), 200

@payment_bp.route('/initialize', methods=['POST'])
def initialize_payment():
    """Initialize payment with selected gateway"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['product_id', 'customer_email', 'customer_name', 'payment_method']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Get product
        product = Product.query.filter_by(
            id=data['product_id'],
            status='approved',
            is_active=True
        ).first()
        
        if not product:
            return jsonify({'error': 'Product not found or not available'}), 404
        
        # Get affiliate link if provided
        affiliate_link = None
        if data.get('affiliate_link_code'):
            affiliate_link = AffiliateLink.query.filter_by(
                link_code=data['affiliate_link_code'],
                is_active=True
            ).first()
        
        # Create transaction record
        transaction = Transaction(
            user_id=product.vendor_id,
            product_id=product.id,
            affiliate_link_id=affiliate_link.id if affiliate_link else None,
            amount=product.price,
            payment_method=data['payment_method'],
            customer_email=data['customer_email'],
            customer_name=data['customer_name'],
            customer_phone=data.get('customer_phone')
        )
        
        transaction.generate_transaction_ref()
        db.session.add(transaction)
        db.session.commit()
        
        # Initialize payment based on selected method
        if data['payment_method'] == 'paystack':
            response = initialize_paystack_payment(transaction, data)
        elif data['payment_method'] == 'flutterwave':
            response = initialize_flutterwave_payment(transaction, data)
        elif data['payment_method'] == 'bank_transfer':
            response = initialize_bank_transfer(transaction, data)
        else:
            return jsonify({'error': 'Unsupported payment method'}), 400
        
        return response
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Payment initialization error: {str(e)}")
        return jsonify({'error': str(e)}), 500

def initialize_paystack_payment(transaction, data):
    """Initialize Paystack payment"""
    try:
        paystack_secret = current_app.config.get('PAYSTACK_SECRET_KEY', 'sk_test_your_secret_key')
        
        payload = {
            'email': transaction.customer_email,
            'amount': int(transaction.amount * 100),  # Convert to kobo
            'reference': transaction.transaction_ref,
            'currency': 'NGN',
            'callback_url': f"{request.host_url}api/payment/paystack/callback",
            'metadata': {
                'transaction_id': transaction.id,
                'product_id': transaction.product_id,
                'customer_name': transaction.customer_name
            }
        }
        
        headers = {
            'Authorization': f'Bearer {paystack_secret}',
            'Content-Type': 'application/json'
        }
        
        response = requests.post(
            'https://api.paystack.co/transaction/initialize',
            json=payload,
            headers=headers
        )
        
        if response.status_code == 200:
            result = response.json()
            
            # Update transaction with payment reference
            transaction.payment_ref = result['data']['reference']
            transaction.gateway_response = json.dumps(result)
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Payment initialized successfully',
                'data': {
                    'authorization_url': result['data']['authorization_url'],
                    'access_code': result['data']['access_code'],
                    'reference': result['data']['reference'],
                    'transaction_id': transaction.id
                }
            }), 200
        else:
            logger.error(f"Paystack initialization failed: {response.text}")
            return jsonify({'error': 'Payment initialization failed'}), 400
            
    except Exception as e:
        logger.error(f"Paystack initialization error: {str(e)}")
        return jsonify({'error': str(e)}), 500

def initialize_flutterwave_payment(transaction, data):
    """Initialize Flutterwave payment"""
    try:
        flutterwave_secret = current_app.config.get('FLUTTERWAVE_SECRET_KEY', 'FLWSECK_TEST-your_secret_key')
        
        payload = {
            'tx_ref': transaction.transaction_ref,
            'amount': str(transaction.amount),
            'currency': 'NGN',
            'redirect_url': f"{request.host_url}api/payment/flutterwave/callback",
            'customer': {
                'email': transaction.customer_email,
                'name': transaction.customer_name,
                'phonenumber': transaction.customer_phone or ''
            },
            'customizations': {
                'title': 'Hisnak Marketplace',
                'description': f'Payment for {transaction.product.name}',
                'logo': f"{request.host_url}static/logo.png"
            },
            'meta': {
                'transaction_id': transaction.id,
                'product_id': transaction.product_id
            }
        }
        
        headers = {
            'Authorization': f'Bearer {flutterwave_secret}',
            'Content-Type': 'application/json'
        }
        
        response = requests.post(
            'https://api.flutterwave.com/v3/payments',
            json=payload,
            headers=headers
        )
        
        if response.status_code == 200:
            result = response.json()
            
            # Update transaction with payment reference
            transaction.payment_ref = result['data']['link']
            transaction.gateway_response = json.dumps(result)
            db.session.commit()
            
            return jsonify({
                'status': 'success',
                'message': 'Payment initialized successfully',
                'data': {
                    'payment_link': result['data']['link'],
                    'reference': transaction.transaction_ref,
                    'transaction_id': transaction.id
                }
            }), 200
        else:
            logger.error(f"Flutterwave initialization failed: {response.text}")
            return jsonify({'error': 'Payment initialization failed'}), 400
            
    except Exception as e:
        logger.error(f"Flutterwave initialization error: {str(e)}")
        return jsonify({'error': str(e)}), 500

def initialize_bank_transfer(transaction, data):
    """Initialize bank transfer payment (manual)"""
    try:
        # For bank transfer, we provide bank details and mark as pending
        bank_details = {
            'account_name': 'Hisnak Marketplace Limited',
            'account_number': '1234567890',
            'bank_name': 'Guaranty Trust Bank',
            'bank_code': '058',
            'amount': float(transaction.amount),
            'reference': transaction.transaction_ref
        }
        
        # Update transaction status
        transaction.status = TransactionStatus.PENDING
        transaction.gateway_response = json.dumps(bank_details)
        db.session.commit()
        
        return jsonify({
            'status': 'success',
            'message': 'Bank transfer details generated',
            'data': {
                'bank_details': bank_details,
                'transaction_id': transaction.id,
                'instructions': 'Please make payment to the account details above and upload proof of payment'
            }
        }), 200
        
    except Exception as e:
        logger.error(f"Bank transfer initialization error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@payment_bp.route('/paystack/webhook', methods=['POST'])
def paystack_webhook():
    """Handle Paystack webhook notifications"""
    try:
        payload = request.get_data()
        signature = request.headers.get('X-Paystack-Signature')
        
        # Verify signature
        paystack_secret = current_app.config.get('PAYSTACK_SECRET_KEY', 'sk_test_your_secret_key')
        if not verify_paystack_signature(payload, signature, paystack_secret):
            return jsonify({'error': 'Invalid signature'}), 400
        
        event = request.get_json()
        
        if event['event'] == 'charge.success':
            # Handle successful payment
            reference = event['data']['reference']
            transaction = Transaction.query.filter_by(transaction_ref=reference).first()
            
            if transaction:
                # Update transaction status
                transaction.status = TransactionStatus.COMPLETED
                transaction.completed_at = datetime.now(timezone.utc)
                transaction.gateway_response = json.dumps(event['data'])
                
                # Process commission distribution
                if transaction.affiliate_link_id:
                    affiliate_link = AffiliateLink.query.get(transaction.affiliate_link_id)
                    if affiliate_link:
                        # Update conversion count
                        affiliate_link.conversions_count += 1
                        
                        # Calculate and create commissions
                        calculate_commissions(transaction, affiliate_link)
                
                db.session.commit()
                logger.info(f"Payment completed for transaction {transaction.id}")
        
        return jsonify({'status': 'success'}), 200
        
    except Exception as e:
        logger.error(f"Paystack webhook error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@payment_bp.route('/flutterwave/webhook', methods=['POST'])
def flutterwave_webhook():
    """Handle Flutterwave webhook notifications"""
    try:
        payload = request.get_data()
        signature = request.headers.get('verif-hash')
        
        # Verify signature
        flutterwave_secret = current_app.config.get('FLUTTERWAVE_WEBHOOK_SECRET', 'your_webhook_secret')
        if not verify_flutterwave_signature(payload, signature, flutterwave_secret):
            return jsonify({'error': 'Invalid signature'}), 400
        
        event = request.get_json()
        
        if event['event'] == 'charge.completed' and event['data']['status'] == 'successful':
            # Handle successful payment
            tx_ref = event['data']['tx_ref']
            transaction = Transaction.query.filter_by(transaction_ref=tx_ref).first()
            
            if transaction:
                # Update transaction status
                transaction.status = TransactionStatus.COMPLETED
                transaction.completed_at = datetime.now(timezone.utc)
                transaction.gateway_response = json.dumps(event['data'])
                
                # Process commission distribution
                if transaction.affiliate_link_id:
                    affiliate_link = AffiliateLink.query.get(transaction.affiliate_link_id)
                    if affiliate_link:
                        # Update conversion count
                        affiliate_link.conversions_count += 1
                        
                        # Calculate and create commissions
                        calculate_commissions(transaction, affiliate_link)
                
                db.session.commit()
                logger.info(f"Payment completed for transaction {transaction.id}")
        
        return jsonify({'status': 'success'}), 200
        
    except Exception as e:
        logger.error(f"Flutterwave webhook error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@payment_bp.route('/verify/<transaction_ref>', methods=['GET'])
def verify_payment(transaction_ref):
    """Verify payment status"""
    try:
        transaction = Transaction.query.filter_by(transaction_ref=transaction_ref).first()
        
        if not transaction:
            return jsonify({'error': 'Transaction not found'}), 404
        
        # Verify with payment gateway
        if transaction.payment_method == 'paystack':
            verification_result = verify_paystack_payment(transaction_ref)
        elif transaction.payment_method == 'flutterwave':
            verification_result = verify_flutterwave_payment(transaction_ref)
        else:
            verification_result = {'status': transaction.status.value}
        
        return jsonify({
            'transaction': transaction.to_dict(),
            'verification': verification_result
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def verify_paystack_payment(reference):
    """Verify payment with Paystack"""
    try:
        paystack_secret = current_app.config.get('PAYSTACK_SECRET_KEY', 'sk_test_your_secret_key')
        
        headers = {
            'Authorization': f'Bearer {paystack_secret}',
            'Content-Type': 'application/json'
        }
        
        response = requests.get(
            f'https://api.paystack.co/transaction/verify/{reference}',
            headers=headers
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return {'status': 'failed', 'message': 'Verification failed'}
            
    except Exception as e:
        logger.error(f"Paystack verification error: {str(e)}")
        return {'status': 'error', 'message': str(e)}

def verify_flutterwave_payment(tx_ref):
    """Verify payment with Flutterwave"""
    try:
        flutterwave_secret = current_app.config.get('FLUTTERWAVE_SECRET_KEY', 'FLWSECK_TEST-your_secret_key')
        
        headers = {
            'Authorization': f'Bearer {flutterwave_secret}',
            'Content-Type': 'application/json'
        }
        
        response = requests.get(
            f'https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref={tx_ref}',
            headers=headers
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return {'status': 'failed', 'message': 'Verification failed'}
            
    except Exception as e:
        logger.error(f"Flutterwave verification error: {str(e)}")
        return {'status': 'error', 'message': str(e)}

# Bank Account Management Routes

@payment_bp.route('/bank-accounts', methods=['GET'])
@token_required
@role_required(['vendor', 'affiliate'])
def get_bank_accounts(current_user):
    """Get user's bank accounts"""
    try:
        accounts = BankAccount.query.filter_by(
            user_id=current_user.id,
            is_active=True
        ).all()
        
        return jsonify({
            'bank_accounts': [account.to_dict() for account in accounts]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@payment_bp.route('/bank-accounts', methods=['POST'])
@token_required
@role_required(['vendor', 'affiliate'])
def add_bank_account(current_user):
    """Add a new bank account"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['account_name', 'account_number', 'bank_name', 'bank_code', 'bvn']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate account number (10 digits)
        if not re.match(r'^\d{10}$', data['account_number']):
            return jsonify({'error': 'Account number must be 10 digits'}), 400
        
        # Validate BVN (11 digits)
        if not re.match(r'^\d{11}$', data['bvn']):
            return jsonify({'error': 'BVN must be 11 digits'}), 400
        
        # Check if account already exists
        existing_account = BankAccount.query.filter_by(
            user_id=current_user.id,
            account_number=data['account_number'],
            bank_code=data['bank_code']
        ).first()
        
        if existing_account:
            return jsonify({'error': 'Bank account already exists'}), 400
        
        # Create new bank account
        bank_account = BankAccount(
            user_id=current_user.id,
            account_name=data['account_name'],
            account_number=data['account_number'],
            bank_name=data['bank_name'],
            bank_code=data['bank_code'],
            bvn=data['bvn'],
            nin=data.get('nin')
        )
        
        db.session.add(bank_account)
        db.session.commit()
        
        return jsonify({
            'message': 'Bank account added successfully',
            'bank_account': bank_account.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@payment_bp.route('/bank-accounts/<account_id>', methods=['PUT'])
@token_required
@role_required(['vendor', 'affiliate'])
def update_bank_account(current_user, account_id):
    """Update bank account"""
    try:
        account = BankAccount.query.filter_by(
            id=account_id,
            user_id=current_user.id
        ).first()
        
        if not account:
            return jsonify({'error': 'Bank account not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        allowed_fields = ['account_name', 'nin']
        for field in allowed_fields:
            if field in data:
                setattr(account, field, data[field])
        
        account.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Bank account updated successfully',
            'bank_account': account.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@payment_bp.route('/bank-accounts/<account_id>', methods=['DELETE'])
@token_required
@role_required(['vendor', 'affiliate'])
def delete_bank_account(current_user, account_id):
    """Delete bank account"""
    try:
        account = BankAccount.query.filter_by(
            id=account_id,
            user_id=current_user.id
        ).first()
        
        if not account:
            return jsonify({'error': 'Bank account not found'}), 404
        
        account.is_active = False
        db.session.commit()
        
        return jsonify({'message': 'Bank account deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Withdrawal Routes

@payment_bp.route('/withdrawals', methods=['GET'])
@token_required
@role_required(['vendor', 'affiliate'])
def get_withdrawals(current_user):
    """Get user's withdrawal history"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        withdrawals = Withdrawal.query.filter_by(user_id=current_user.id)\
            .order_by(Withdrawal.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'withdrawals': [withdrawal.to_dict() for withdrawal in withdrawals.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': withdrawals.total,
                'pages': withdrawals.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@payment_bp.route('/withdrawals', methods=['POST'])
@token_required
@role_required(['vendor', 'affiliate'])
def request_withdrawal(current_user):
    """Request withdrawal"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('amount') or not data.get('bank_account_id'):
            return jsonify({'error': 'Amount and bank account are required'}), 400
        
        amount = Decimal(str(data['amount']))
        
        # Check minimum withdrawal amount (₦2000)
        if amount < 2000:
            return jsonify({'error': 'Minimum withdrawal amount is ₦2,000'}), 400
        
        # Check user balance
        current_balance = current_user.get_balance()
        if amount > current_balance:
            return jsonify({'error': 'Insufficient balance'}), 400
        
        # Verify bank account
        bank_account = BankAccount.query.filter_by(
            id=data['bank_account_id'],
            user_id=current_user.id,
            is_active=True
        ).first()
        
        if not bank_account:
            return jsonify({'error': 'Invalid bank account'}), 404
        
        # Create withdrawal request
        withdrawal = Withdrawal(
            user_id=current_user.id,
            bank_account_id=bank_account.id,
            amount=amount,
            reason=data.get('reason')
        )
        
        withdrawal.generate_reference()
        
        db.session.add(withdrawal)
        db.session.commit()
        
        return jsonify({
            'message': 'Withdrawal request submitted successfully',
            'withdrawal': withdrawal.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

