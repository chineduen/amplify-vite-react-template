import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Calendar, 
  User, 
  ArrowRight, 
  TrendingUp,
  BookOpen,
  Target,
  DollarSign
} from 'lucide-react';

const BlogPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { value: 'all', label: 'All Posts', count: 24 },
    { value: 'tips', label: 'Tips & Strategies', count: 8 },
    { value: 'success-stories', label: 'Success Stories', count: 6 },
    { value: 'platform-updates', label: 'Platform Updates', count: 5 },
    { value: 'marketing', label: 'Marketing', count: 5 }
  ];

  const featuredPost = {
    id: 1,
    title: "How Sarah Built a ₦500K Monthly Income Through Affiliate Marketing",
    excerpt: "Discover the exact strategies and techniques Sarah used to build a six-figure monthly income through our affiliate program in just 8 months.",
    content: "Learn the step-by-step process, tools, and mindset shifts that led to her success...",
    author: "Hisnak Team",
    date: "2024-02-15",
    readTime: "8 min read",
    category: "success-stories",
    image: "/api/placeholder/600/300",
    featured: true,
    tags: ["Success Story", "Affiliate Marketing", "Income"]
  };

  const blogPosts = [
    {
      id: 2,
      title: "10 Proven Strategies to Increase Your Affiliate Conversions",
      excerpt: "Boost your affiliate marketing performance with these data-driven strategies that top affiliates use to maximize their earnings.",
      author: "Marketing Team",
      date: "2024-02-12",
      readTime: "6 min read",
      category: "tips",
      image: "/api/placeholder/400/250",
      tags: ["Conversion", "Strategy", "Tips"]
    },
    {
      id: 3,
      title: "New AI-Powered Analytics Dashboard Released",
      excerpt: "We've launched an advanced analytics dashboard with AI insights to help you optimize your affiliate marketing campaigns.",
      author: "Product Team",
      date: "2024-02-10",
      readTime: "4 min read",
      category: "platform-updates",
      image: "/api/placeholder/400/250",
      tags: ["Product Update", "Analytics", "AI"]
    },
    {
      id: 4,
      title: "Building Your Personal Brand as an Affiliate Marketer",
      excerpt: "Learn how to establish yourself as a trusted authority in your niche and build long-term relationships with your audience.",
      author: "Content Team",
      date: "2024-02-08",
      readTime: "7 min read",
      category: "marketing",
      image: "/api/placeholder/400/250",
      tags: ["Branding", "Authority", "Trust"]
    },
    {
      id: 5,
      title: "From Zero to Hero: Mike's Journey to ₦300K Monthly",
      excerpt: "Follow Mike's inspiring journey from complete beginner to successful affiliate earning ₦300K monthly in just 6 months.",
      author: "Success Team",
      date: "2024-02-05",
      readTime: "5 min read",
      category: "success-stories",
      image: "/api/placeholder/400/250",
      tags: ["Success Story", "Journey", "Inspiration"]
    },
    {
      id: 6,
      title: "Social Media Marketing for Affiliates: Complete Guide",
      excerpt: "Master social media marketing with our comprehensive guide covering all major platforms and proven strategies.",
      author: "Marketing Team",
      date: "2024-02-03",
      readTime: "10 min read",
      category: "tips",
      image: "/api/placeholder/400/250",
      tags: ["Social Media", "Marketing", "Guide"]
    },
    {
      id: 7,
      title: "Understanding the Two-Level Commission System",
      excerpt: "Deep dive into how our innovative two-level commission system works and how to maximize your earnings from both levels.",
      author: "Education Team",
      date: "2024-02-01",
      readTime: "6 min read",
      category: "tips",
      image: "/api/placeholder/400/250",
      tags: ["Commission", "System", "Education"]
    }
  ];

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'tips':
        return <Target className="h-4 w-4" />;
      case 'success-stories':
        return <TrendingUp className="h-4 w-4" />;
      case 'platform-updates':
        return <BookOpen className="h-4 w-4" />;
      case 'marketing':
        return <DollarSign className="h-4 w-4" />;
      default:
        return <BookOpen className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'tips':
        return 'bg-blue-100 text-blue-800';
      case 'success-stories':
        return 'bg-green-100 text-green-800';
      case 'platform-updates':
        return 'bg-purple-100 text-purple-800';
      case 'marketing':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Hisnak Marketplace Blog
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Tips, strategies, and success stories to help you succeed in affiliate marketing
          </p>
        </div>

        {/* Search and Categories */}
        <div className="mb-12">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search articles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Categories */}
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category.value}
                  variant={selectedCategory === category.value ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(category.value)}
                  className="flex items-center space-x-2"
                >
                  {getCategoryIcon(category.value)}
                  <span>{category.label}</span>
                  <Badge variant="secondary" className="ml-1">
                    {category.count}
                  </Badge>
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Featured Post */}
        {selectedCategory === 'all' && !searchTerm && (
          <Card className="mb-12 overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/2">
                <div className="h-64 md:h-full bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-500">Featured Image</span>
                </div>
              </div>
              <div className="md:w-1/2 p-8">
                <Badge className={getCategoryColor(featuredPost.category)} variant="secondary">
                  Featured Story
                </Badge>
                <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mt-4 mb-4">
                  {featuredPost.title}
                </h2>
                <p className="text-gray-600 mb-6">
                  {featuredPost.excerpt}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-1" />
                      {featuredPost.author}
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {featuredPost.date}
                    </div>
                    <span>{featuredPost.readTime}</span>
                  </div>
                  <Button>
                    Read More
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <Card key={post.id} className="group hover:shadow-lg transition-shadow duration-200">
              <div className="aspect-video bg-gray-200 rounded-t-lg flex items-center justify-center">
                <span className="text-gray-500">Article Image</span>
              </div>
              
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge className={getCategoryColor(post.category)} variant="secondary">
                    {getCategoryIcon(post.category)}
                    <span className="ml-1 capitalize">{post.category.replace('-', ' ')}</span>
                  </Badge>
                  <span className="text-xs text-gray-500">{post.readTime}</span>
                </div>
                <CardTitle className="text-lg group-hover:text-primary transition-colors line-clamp-2">
                  {post.title}
                </CardTitle>
              </CardHeader>
              
              <CardContent>
                <CardDescription className="line-clamp-3 mb-4">
                  {post.excerpt}
                </CardDescription>
                
                <div className="flex flex-wrap gap-1 mb-4">
                  {post.tags.slice(0, 2).map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 text-sm text-gray-500">
                    <div className="flex items-center">
                      <User className="h-3 w-3 mr-1" />
                      {post.author}
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      {post.date}
                    </div>
                  </div>
                  <Button size="sm" variant="ghost">
                    Read More
                    <ArrowRight className="ml-1 h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* No Results */}
        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No articles found</h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search terms or browse different categories.
            </p>
            <Button onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
            }}>
              Clear Filters
            </Button>
          </div>
        )}

        {/* Load More */}
        {filteredPosts.length > 0 && (
          <div className="text-center mt-12">
            <Button variant="outline" size="lg">
              Load More Articles
            </Button>
          </div>
        )}

        {/* Newsletter Signup */}
        <Card className="mt-16 bg-primary/5 border-primary/20">
          <CardContent className="text-center py-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Stay Updated with Our Latest Tips
            </h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Get the latest affiliate marketing strategies, success stories, and platform updates 
              delivered directly to your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                placeholder="Enter your email"
                className="flex-1"
              />
              <Button>
                Subscribe
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              No spam, unsubscribe at any time.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default BlogPage;

