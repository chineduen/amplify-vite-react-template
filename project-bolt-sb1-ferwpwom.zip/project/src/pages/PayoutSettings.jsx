import React, { useState, useContext } from 'react';
import { AuthContext } from '../App';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  DollarSign,
  CreditCard,
  Bank,
  Plus,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  CheckCircle,
  AlertCircle,
  Clock,
  Download,
  Calendar,
  Shield,
  Info
} from 'lucide-react';

const PayoutSettings = () => {
  const { user } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState('account');
  const [showAccountNumber, setShowAccountNumber] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Nigerian Banks
  const nigerianBanks = [
    { code: '044', name: 'Access Bank' },
    { code: '014', name: 'Afribank Nigeria Plc' },
    { code: '023', name: 'Citibank Nigeria Limited' },
    { code: '050', name: 'Ecobank Nigeria Plc' },
    { code: '011', name: 'First Bank of Nigeria Limited' },
    { code: '214', name: 'First City Monument Bank Limited' },
    { code: '070', name: 'Fidelity Bank Plc' },
    { code: '058', name: 'Guaranty Trust Bank Plc' },
    { code: '030', name: 'Heritage Banking Company Ltd' },
    { code: '082', name: 'Keystone Bank Limited' },
    { code: '076', name: 'Polaris Bank Limited' },
    { code: '221', name: 'Stanbic IBTC Bank Plc' },
    { code: '068', name: 'Standard Chartered Bank Nigeria Limited' },
    { code: '232', name: 'Sterling Bank Plc' },
    { code: '033', name: 'United Bank For Africa Plc' },
    { code: '032', name: 'Union Bank of Nigeria Plc' },
    { code: '035', name: 'Wema Bank Plc' },
    { code: '057', name: 'Zenith Bank Plc' }
  ];

  // Sample data
  const [bankAccount, setBankAccount] = useState({
    accountName: 'John Doe',
    accountNumber: '1234567890',
    bankName: 'Guaranty Trust Bank Plc',
    bankCode: '058',
    bvn: '12345678901',
    nin: '12345678901'
  });

  const [newBankAccount, setNewBankAccount] = useState({
    accountName: '',
    accountNumber: '',
    bankName: '',
    bankCode: '',
    bvn: '',
    nin: ''
  });

  const [withdrawalForm, setWithdrawalForm] = useState({
    amount: '',
    reason: '',
    accountId: '1'
  });

  const withdrawalHistory = [
    {
      id: 1,
      amount: 25000,
      status: 'completed',
      date: '2024-02-10',
      transactionId: 'TXN123456789',
      bankAccount: '****7890',
      bankName: 'GTBank',
      processingTime: '2 business days'
    },
    {
      id: 2,
      amount: 15000,
      status: 'processing',
      date: '2024-02-15',
      transactionId: 'TXN987654321',
      bankAccount: '****7890',
      bankName: 'GTBank',
      processingTime: '1-3 business days'
    },
    {
      id: 3,
      amount: 30000,
      status: 'pending',
      date: '2024-02-16',
      transactionId: 'TXN456789123',
      bankAccount: '****7890',
      bankName: 'GTBank',
      processingTime: 'Pending approval'
    }
  ];

  const currentBalance = user?.balance || 45750;
  const minimumWithdrawal = 2000;

  const handleBankAccountSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Validate account number
      if (newBankAccount.accountNumber.length !== 10) {
        throw new Error('Account number must be exactly 10 digits');
      }

      // Validate BVN
      if (newBankAccount.bvn.length !== 11) {
        throw new Error('BVN must be exactly 11 digits');
      }

      // Validate NIN
      if (newBankAccount.nin.length !== 11) {
        throw new Error('NIN must be exactly 11 digits');
      }

      // Simulate API call for account verification
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Update bank account
      setBankAccount(newBankAccount);
      setSuccess('Bank account added successfully!');
      setNewBankAccount({
        accountName: '',
        accountNumber: '',
        bankName: '',
        bankCode: '',
        bvn: '',
        nin: ''
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleWithdrawalSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const amount = parseFloat(withdrawalForm.amount);

      if (amount < minimumWithdrawal) {
        throw new Error(`Minimum withdrawal amount is ₦${minimumWithdrawal.toLocaleString()}`);
      }

      if (amount > currentBalance) {
        throw new Error('Insufficient balance');
      }

      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));

      setSuccess(`Withdrawal request of ₦${amount.toLocaleString()} submitted successfully!`);
      setWithdrawalForm({
        amount: '',
        reason: '',
        accountId: '1'
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const maskAccountNumber = (accountNumber) => {
    if (!accountNumber) return '';
    return `****${accountNumber.slice(-4)}`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4" />;
      case 'processing':
        return <Clock className="h-4 w-4" />;
      case 'pending':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Clock className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Payout Settings</h1>
          <p className="text-gray-600">Manage your bank accounts and withdrawal settings</p>
        </div>

        {/* Balance Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <DollarSign className="h-5 w-5 mr-2" />
              Available Balance
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold text-primary">₦{currentBalance.toLocaleString()}</div>
                <p className="text-sm text-gray-600">
                  Minimum withdrawal: ₦{minimumWithdrawal.toLocaleString()}
                </p>
              </div>
              <div className="text-right">
                <Badge variant="outline" className="mb-2">
                  {user?.role === 'vendor' ? 'Vendor Account' : 'Affiliate Account'}
                </Badge>
                <p className="text-xs text-gray-500">
                  KYC Status: <span className="text-green-600 font-medium">Verified</span>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="account">Bank Account</TabsTrigger>
            <TabsTrigger value="withdraw">Withdraw</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          {/* Bank Account Tab */}
          <TabsContent value="account" className="space-y-6">
            {/* Current Bank Account */}
            {bankAccount.accountNumber && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bank className="h-5 w-5 mr-2" />
                    Current Bank Account
                  </CardTitle>
                  <CardDescription>Your verified bank account for withdrawals</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-600">Account Name</Label>
                      <p className="font-medium">{bankAccount.accountName}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-600">Account Number</Label>
                      <div className="flex items-center space-x-2">
                        <p className="font-medium font-mono">
                          {showAccountNumber ? bankAccount.accountNumber : maskAccountNumber(bankAccount.accountNumber)}
                        </p>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setShowAccountNumber(!showAccountNumber)}
                        >
                          {showAccountNumber ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </Button>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-600">Bank Name</Label>
                      <p className="font-medium">{bankAccount.bankName}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-600">Status</Label>
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Verified
                      </Badge>
                    </div>
                  </div>
                  <div className="flex space-x-2 mt-4">
                    <Button size="sm" variant="outline">
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Remove
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Add Bank Account */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Plus className="h-5 w-5 mr-2" />
                  {bankAccount.accountNumber ? 'Add Another Bank Account' : 'Add Bank Account'}
                </CardTitle>
                <CardDescription>
                  Add your Nigerian bank account details for withdrawals
                </CardDescription>
              </CardHeader>
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert className="mb-4">
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>{success}</AlertDescription>
                  </Alert>
                )}

                <form onSubmit={handleBankAccountSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="accountName">Account Name *</Label>
                      <Input
                        id="accountName"
                        value={newBankAccount.accountName}
                        onChange={(e) => setNewBankAccount({...newBankAccount, accountName: e.target.value})}
                        placeholder="Enter account holder name"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="accountNumber">Account Number *</Label>
                      <Input
                        id="accountNumber"
                        value={newBankAccount.accountNumber}
                        onChange={(e) => setNewBankAccount({...newBankAccount, accountNumber: e.target.value})}
                        placeholder="10-digit account number"
                        maxLength={10}
                        pattern="[0-9]{10}"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bankName">Bank Name *</Label>
                    <Select 
                      value={newBankAccount.bankCode} 
                      onValueChange={(value) => {
                        const bank = nigerianBanks.find(b => b.code === value);
                        setNewBankAccount({
                          ...newBankAccount, 
                          bankCode: value,
                          bankName: bank?.name || ''
                        });
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your bank" />
                      </SelectTrigger>
                      <SelectContent>
                        {nigerianBanks.map((bank) => (
                          <SelectItem key={bank.code} value={bank.code}>
                            {bank.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="bvn">BVN (Bank Verification Number) *</Label>
                      <Input
                        id="bvn"
                        value={newBankAccount.bvn}
                        onChange={(e) => setNewBankAccount({...newBankAccount, bvn: e.target.value})}
                        placeholder="11-digit BVN"
                        maxLength={11}
                        pattern="[0-9]{11}"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="nin">NIN (National Identification Number) *</Label>
                      <Input
                        id="nin"
                        value={newBankAccount.nin}
                        onChange={(e) => setNewBankAccount({...newBankAccount, nin: e.target.value})}
                        placeholder="11-digit NIN"
                        maxLength={11}
                        pattern="[0-9]{11}"
                        required
                      />
                    </div>
                  </div>

                  <Alert>
                    <Shield className="h-4 w-4" />
                    <AlertDescription>
                      Your bank details are encrypted and stored securely. BVN and NIN are required for 
                      identity verification and compliance with Nigerian financial regulations.
                    </AlertDescription>
                  </Alert>

                  <Button type="submit" disabled={loading} className="w-full">
                    {loading ? 'Verifying Account...' : 'Add Bank Account'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Withdraw Tab */}
          <TabsContent value="withdraw" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="h-5 w-5 mr-2" />
                  Request Withdrawal
                </CardTitle>
                <CardDescription>
                  Withdraw your earnings to your verified bank account
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!bankAccount.accountNumber ? (
                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      Please add a bank account first before making withdrawal requests.
                    </AlertDescription>
                  </Alert>
                ) : (
                  <>
                    {error && (
                      <Alert variant="destructive" className="mb-4">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    )}

                    {success && (
                      <Alert className="mb-4">
                        <CheckCircle className="h-4 w-4" />
                        <AlertDescription>{success}</AlertDescription>
                      </Alert>
                    )}

                    <form onSubmit={handleWithdrawalSubmit} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="amount">Withdrawal Amount (₦) *</Label>
                        <Input
                          id="amount"
                          type="number"
                          min={minimumWithdrawal}
                          max={currentBalance}
                          value={withdrawalForm.amount}
                          onChange={(e) => setWithdrawalForm({...withdrawalForm, amount: e.target.value})}
                          placeholder={`Minimum ₦${minimumWithdrawal.toLocaleString()}`}
                          required
                        />
                        <p className="text-xs text-gray-500">
                          Available balance: ₦{currentBalance.toLocaleString()}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="reason">Reason (Optional)</Label>
                        <Textarea
                          id="reason"
                          value={withdrawalForm.reason}
                          onChange={(e) => setWithdrawalForm({...withdrawalForm, reason: e.target.value})}
                          placeholder="Specify the purpose of this withdrawal"
                          rows={3}
                        />
                      </div>

                      <div className="p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-medium mb-2">Withdrawal Details</h4>
                        <div className="space-y-1 text-sm">
                          <div className="flex justify-between">
                            <span>Bank Account:</span>
                            <span>{maskAccountNumber(bankAccount.accountNumber)} - {bankAccount.bankName}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Processing Time:</span>
                            <span>1-3 business days</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Transaction Fee:</span>
                            <span>₦0 (Free)</span>
                          </div>
                        </div>
                      </div>

                      <Button type="submit" disabled={loading} className="w-full">
                        {loading ? 'Processing...' : 'Request Withdrawal'}
                      </Button>
                    </form>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center">
                      <Calendar className="h-5 w-5 mr-2" />
                      Withdrawal History
                    </CardTitle>
                    <CardDescription>Track your withdrawal requests and their status</CardDescription>
                  </div>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {withdrawalHistory.map((withdrawal) => (
                    <div key={withdrawal.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-lg">₦{withdrawal.amount.toLocaleString()}</h4>
                          <p className="text-sm text-gray-600">
                            To {withdrawal.bankAccount} - {withdrawal.bankName}
                          </p>
                          <p className="text-xs text-gray-500">
                            Transaction ID: {withdrawal.transactionId}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge className={getStatusColor(withdrawal.status)}>
                            {getStatusIcon(withdrawal.status)}
                            <span className="ml-1 capitalize">{withdrawal.status}</span>
                          </Badge>
                          <p className="text-xs text-gray-500 mt-1">{withdrawal.date}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Processing Time:</span>
                        <span>{withdrawal.processingTime}</span>
                      </div>
                    </div>
                  ))}
                </div>

                {withdrawalHistory.length === 0 && (
                  <div className="text-center py-8">
                    <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No withdrawals yet</h3>
                    <p className="text-gray-600">Your withdrawal history will appear here once you make your first request.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default PayoutSettings;

