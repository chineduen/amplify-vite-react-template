import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowRight, 
  Users, 
  Target, 
  Heart, 
  Shield, 
  Zap, 
  Globe,
  Award,
  TrendingUp,
  CheckCircle
} from 'lucide-react';

const AboutPage = () => {
  const values = [
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Transparency",
      description: "We believe in complete transparency in all our operations, from commission tracking to payout processes."
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "Community",
      description: "Building a supportive community where affiliates and vendors can grow together and share knowledge."
    },
    {
      icon: <Zap className="h-8 w-8 text-primary" />,
      title: "Innovation",
      description: "Continuously improving our platform with cutting-edge technology and AI-powered features."
    },
    {
      icon: <Heart className="h-8 w-8 text-primary" />,
      title: "Success",
      description: "Your success is our success. We're committed to helping every user achieve their financial goals."
    }
  ];

  const stats = [
    { number: "15,000+", label: "Active Users" },
    { number: "₦50M+", label: "Commissions Paid" },
    { number: "500+", label: "Products Listed" },
    { number: "98%", label: "User Satisfaction" }
  ];

  const team = [
    {
      name: "Adebayo Johnson",
      role: "CEO & Founder",
      bio: "Former tech executive with 15+ years in fintech and e-commerce. Passionate about empowering entrepreneurs.",
      avatar: "AJ"
    },
    {
      name: "Sarah Okafor",
      role: "CTO",
      bio: "AI and blockchain expert who previously led engineering teams at major tech companies.",
      avatar: "SO"
    },
    {
      name: "Michael Chen",
      role: "Head of Marketing",
      bio: "Digital marketing veteran with expertise in affiliate networks and performance marketing.",
      avatar: "MC"
    },
    {
      name: "Fatima Al-Hassan",
      role: "Head of Operations",
      bio: "Operations specialist focused on scaling platforms and ensuring seamless user experiences.",
      avatar: "FA"
    }
  ];

  const milestones = [
    {
      year: "2023",
      title: "Platform Launch",
      description: "Hisnak Marketplace officially launched with our innovative two-level commission system."
    },
    {
      year: "2023",
      title: "1,000 Users",
      description: "Reached our first milestone of 1,000 registered users within 3 months."
    },
    {
      year: "2024",
      title: "AI Integration",
      description: "Launched AI-powered analytics and content generation tools for affiliates."
    },
    {
      year: "2024",
      title: "₦10M Milestone",
      description: "Processed over ₦10 million in commission payments to our affiliate network."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-white to-primary/5 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="mb-4" variant="outline">
              About Hisnak Marketplace
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Empowering the Future of
              <span className="text-primary"> Affiliate Marketing</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              We're building the most advanced affiliate networking platform that connects 
              vendors, affiliates, and customers in a transparent, profitable ecosystem 
              powered by AI and innovative commission structures.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" className="w-full sm:w-auto">
                  Join Our Mission
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/contact">
                <Button variant="outline" size="lg" className="w-full sm:w-auto">
                  Get in Touch
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Our Mission
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                To democratize affiliate marketing by creating a platform where anyone can 
                build a sustainable income through our innovative two-level commission system, 
                advanced AI tools, and supportive community.
              </p>
              <p className="text-lg text-gray-600 mb-8">
                We believe that success should be accessible to everyone, regardless of their 
                background or experience level. That's why we've built a platform that combines 
                cutting-edge technology with human-centered design to help our users achieve 
                their financial goals.
              </p>
              <div className="flex items-center space-x-4">
                <CheckCircle className="h-6 w-6 text-green-500" />
                <span className="text-lg font-medium">Transparent commission tracking</span>
              </div>
              <div className="flex items-center space-x-4 mt-2">
                <CheckCircle className="h-6 w-6 text-green-500" />
                <span className="text-lg font-medium">AI-powered optimization tools</span>
              </div>
              <div className="flex items-center space-x-4 mt-2">
                <CheckCircle className="h-6 w-6 text-green-500" />
                <span className="text-lg font-medium">Supportive community network</span>
              </div>
            </div>
            <div className="bg-primary/5 rounded-2xl p-8">
              <div className="text-center">
                <Target className="h-16 w-16 text-primary mx-auto mb-6" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
                <p className="text-gray-600">
                  To become the world's leading affiliate marketing platform, 
                  empowering millions of entrepreneurs to build sustainable 
                  businesses and achieve financial freedom.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              The principles that guide everything we do and shape our platform's culture.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center border-0 shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="mb-4 flex justify-center">{value.icon}</div>
                  <CardTitle className="text-xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {value.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Journey
            </h2>
            <p className="text-xl text-gray-600">
              Key milestones in building the future of affiliate marketing.
            </p>
          </div>
          
          <div className="space-y-8">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex items-start space-x-6">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-white font-bold">{milestone.year.slice(-2)}</span>
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {milestone.title}
                  </h3>
                  <p className="text-gray-600">{milestone.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Meet Our Team
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              The passionate individuals behind Hisnak Marketplace, dedicated to your success.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="text-center border-0 shadow-lg">
                <CardContent className="pt-6">
                  <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-primary font-bold text-xl">{member.avatar}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-1">
                    {member.name}
                  </h3>
                  <p className="text-primary font-medium mb-3">{member.role}</p>
                  <p className="text-sm text-gray-600">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Powered by Advanced Technology
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Our platform leverages cutting-edge technology including artificial intelligence, 
                blockchain security, and real-time analytics to provide the best possible 
                experience for our users.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <Zap className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-medium">AI-powered analytics and insights</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <Shield className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-medium">Bank-level security and encryption</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <TrendingUp className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-medium">Real-time performance tracking</span>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                    <Globe className="h-4 w-4 text-primary" />
                  </div>
                  <span className="font-medium">Global payment processing</span>
                </div>
              </div>
            </div>
            <div className="bg-primary/5 rounded-2xl p-8">
              <div className="text-center">
                <Award className="h-16 w-16 text-primary mx-auto mb-6" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Industry Recognition</h3>
                <p className="text-gray-600 mb-6">
                  Hisnak Marketplace has been recognized as one of the most innovative 
                  affiliate marketing platforms in Nigeria.
                </p>
                <div className="space-y-2">
                  <Badge variant="outline">Best Fintech Innovation 2024</Badge>
                  <Badge variant="outline">Top Affiliate Platform</Badge>
                  <Badge variant="outline">AI Excellence Award</Badge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Join Our Mission?
          </h2>
          <p className="text-xl text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
            Be part of the future of affiliate marketing. Join thousands of successful 
            affiliates and vendors who are building their dreams with Hisnak Marketplace.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                Get Started Today
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/affiliate-program">
              <Button size="lg" variant="outline" className="w-full sm:w-auto border-white text-white hover:bg-white hover:text-primary">
                Learn More
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;

