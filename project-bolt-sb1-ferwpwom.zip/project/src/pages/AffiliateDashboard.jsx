import React, { useState, useContext } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { AuthContext } from '../App';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  DollarSign,
  Users,
  TrendingUp,
  Eye,
  Copy,
  Share2,
  Download,
  Calendar,
  Filter,
  Search,
  ExternalLink,
  Gift,
  Target,
  Award,
  Clock,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

const AffiliateDashboard = () => {
  const { user } = useContext(AuthContext);
  const location = useLocation();
  const [selectedPeriod, setSelectedPeriod] = useState('7d');

  // Sample data - replace with real API calls
  const stats = {
    totalEarnings: 45750,
    thisMonthEarnings: 12500,
    totalClicks: 2847,
    conversions: 156,
    conversionRate: 5.5,
    activeReferrals: 23,
    pendingCommissions: 3200
  };

  const earningsData = [
    { date: '2024-01-01', direct: 2400, referral: 400 },
    { date: '2024-01-02', direct: 1398, referral: 210 },
    { date: '2024-01-03', direct: 9800, referral: 290 },
    { date: '2024-01-04', direct: 3908, referral: 300 },
    { date: '2024-01-05', direct: 4800, referral: 181 },
    { date: '2024-01-06', direct: 3800, referral: 250 },
    { date: '2024-01-07', direct: 4300, referral: 210 }
  ];

  const topProducts = [
    { id: 1, name: 'Digital Marketing Course', sales: 45, commission: 15750, rate: 50 },
    { id: 2, name: 'Web Development Bundle', sales: 32, commission: 9600, rate: 60 },
    { id: 3, name: 'SEO Tools Package', sales: 28, commission: 8400, rate: 45 },
    { id: 4, name: 'Social Media Templates', sales: 51, commission: 7650, rate: 30 }
  ];

  const referrals = [
    { id: 1, name: 'John Smith', email: 'john@example.com', joinDate: '2024-01-15', sales: 12, earnings: 1200, status: 'active' },
    { id: 2, name: 'Sarah Johnson', email: 'sarah@example.com', joinDate: '2024-01-20', sales: 8, earnings: 800, status: 'active' },
    { id: 3, name: 'Mike Wilson', email: 'mike@example.com', joinDate: '2024-01-25', sales: 5, earnings: 500, status: 'pending' },
    { id: 4, name: 'Lisa Brown', email: 'lisa@example.com', joinDate: '2024-02-01', sales: 15, earnings: 1500, status: 'active' }
  ];

  const recentTransactions = [
    { id: 1, type: 'direct', product: 'Digital Marketing Course', amount: 750, date: '2024-02-15', status: 'completed' },
    { id: 2, type: 'referral', referrer: 'John Smith', amount: 120, date: '2024-02-14', status: 'completed' },
    { id: 3, type: 'direct', product: 'Web Development Bundle', amount: 480, date: '2024-02-13', status: 'pending' },
    { id: 4, type: 'referral', referrer: 'Sarah Johnson', amount: 80, date: '2024-02-12', status: 'completed' }
  ];

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    // Add toast notification here
  };

  const generateAffiliateLink = (productId) => {
    return `https://hisnak.com/product/${productId}?ref=${user.referralCode}`;
  };

  const generateReferralLink = () => {
    return `https://hisnak.com/register?ref=${user.referralCode}`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Affiliate Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user.name}! Here's your performance overview.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₦{stats.totalEarnings.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +20.1% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">This Month</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₦{stats.thisMonthEarnings.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +15.3% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Referrals</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeReferrals}</div>
              <p className="text-xs text-muted-foreground">
                +3 new this month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.conversionRate}%</div>
              <p className="text-xs text-muted-foreground">
                +0.5% from last month
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="referrals">Referrals</TabsTrigger>
            <TabsTrigger value="links">Links</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Earnings Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Earnings Overview</CardTitle>
                  <CardDescription>Your direct and referral earnings over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={earningsData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="direct" stackId="a" fill="#8884d8" name="Direct Sales" />
                      <Bar dataKey="referral" stackId="a" fill="#82ca9d" name="Referral Bonus" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Top Products */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Products</CardTitle>
                  <CardDescription>Products generating the most commission</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topProducts.map((product) => (
                      <div key={product.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium">{product.name}</h4>
                          <p className="text-sm text-gray-600">{product.sales} sales • {product.rate}% commission</p>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">₦{product.commission.toLocaleString()}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>Your latest commission earnings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentTransactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-2 h-2 rounded-full ${
                          transaction.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500'
                        }`} />
                        <div>
                          <p className="font-medium">
                            {transaction.type === 'direct' ? transaction.product : `Referral from ${transaction.referrer}`}
                          </p>
                          <p className="text-sm text-gray-600">{transaction.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">₦{transaction.amount}</div>
                        <Badge variant={transaction.status === 'completed' ? 'default' : 'secondary'}>
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Available Products</CardTitle>
                <CardDescription>Browse and promote products to earn commissions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-6">
                  <div className="flex-1">
                    <Input placeholder="Search products..." />
                  </div>
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {topProducts.map((product) => (
                    <Card key={product.id}>
                      <CardHeader>
                        <CardTitle className="text-lg">{product.name}</CardTitle>
                        <CardDescription>Commission: {product.rate}%</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex justify-between text-sm">
                            <span>Your Sales:</span>
                            <span className="font-medium">{product.sales}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Total Earned:</span>
                            <span className="font-medium">₦{product.commission.toLocaleString()}</span>
                          </div>
                          <div className="flex space-x-2">
                            <Button 
                              size="sm" 
                              className="flex-1"
                              onClick={() => copyToClipboard(generateAffiliateLink(product.id))}
                            >
                              <Copy className="h-4 w-4 mr-2" />
                              Copy Link
                            </Button>
                            <Button size="sm" variant="outline">
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Referrals Tab */}
          <TabsContent value="referrals" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Your Referral Network</CardTitle>
                  <CardDescription>People you've referred to the platform</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {referrals.map((referral) => (
                      <div key={referral.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                            <span className="text-primary font-medium">
                              {referral.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div>
                            <h4 className="font-medium">{referral.name}</h4>
                            <p className="text-sm text-gray-600">{referral.email}</p>
                            <p className="text-xs text-gray-500">Joined {referral.joinDate}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">₦{referral.earnings}</div>
                          <p className="text-sm text-gray-600">{referral.sales} sales</p>
                          <Badge variant={referral.status === 'active' ? 'default' : 'secondary'}>
                            {referral.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Referral Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <div className="text-2xl font-bold text-primary">{stats.activeReferrals}</div>
                    <p className="text-sm text-gray-600">Active Referrals</p>
                  </div>
                  
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">₦4,000</div>
                    <p className="text-sm text-gray-600">Referral Earnings</p>
                  </div>

                  <Button className="w-full" onClick={() => copyToClipboard(generateReferralLink())}>
                    <Share2 className="h-4 w-4 mr-2" />
                    Share Referral Link
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Links Tab */}
          <TabsContent value="links" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Your Affiliate Links</CardTitle>
                <CardDescription>Manage and track your promotional links</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="p-4 bg-primary/5 rounded-lg">
                    <h4 className="font-medium mb-2">Your Referral Code</h4>
                    <div className="flex items-center space-x-2">
                      <Input value={user.referralCode} readOnly className="font-mono" />
                      <Button onClick={() => copyToClipboard(user.referralCode)}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium mb-2">General Referral Link</h4>
                    <div className="flex items-center space-x-2">
                      <Input value={generateReferralLink()} readOnly className="text-sm" />
                      <Button onClick={() => copyToClipboard(generateReferralLink())}>
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium">Product-Specific Links</h4>
                    {topProducts.map((product) => (
                      <div key={product.id} className="p-4 border rounded-lg">
                        <h5 className="font-medium mb-2">{product.name}</h5>
                        <div className="flex items-center space-x-2">
                          <Input 
                            value={generateAffiliateLink(product.id)} 
                            readOnly 
                            className="text-sm" 
                          />
                          <Button onClick={() => copyToClipboard(generateAffiliateLink(product.id))}>
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Transactions Tab */}
          <TabsContent value="transactions" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Transaction History</CardTitle>
                    <CardDescription>Complete record of your earnings and commissions</CardDescription>
                  </div>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentTransactions.map((transaction) => (
                    <div key={transaction.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${
                          transaction.type === 'direct' ? 'bg-blue-500' : 'bg-green-500'
                        }`} />
                        <div>
                          <h4 className="font-medium">
                            {transaction.type === 'direct' ? 'Direct Sale' : 'Referral Bonus'}
                          </h4>
                          <p className="text-sm text-gray-600">
                            {transaction.type === 'direct' ? transaction.product : `From ${transaction.referrer}`}
                          </p>
                          <p className="text-xs text-gray-500">{transaction.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">₦{transaction.amount}</div>
                        <Badge variant={transaction.status === 'completed' ? 'default' : 'secondary'}>
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AffiliateDashboard;

