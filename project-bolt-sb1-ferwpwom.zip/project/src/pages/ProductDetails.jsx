import React, { useState, useContext } from 'react';
import { useParams, Link } from 'react-router-dom';
import { AuthContext } from '../App';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Star, 
  Users, 
  TrendingUp, 
  DollarSign, 
  Share2, 
  Heart, 
  Copy, 
  ExternalLink,
  CheckCircle,
  AlertCircle,
  Play,
  Download,
  Eye,
  ThumbsUp,
  MessageCircle
} from 'lucide-react';

const ProductDetails = () => {
  const { id } = useParams();
  const { user } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState('overview');
  const [affiliateLink, setAffiliateLink] = useState('');
  const [linkGenerated, setLinkGenerated] = useState(false);
  const [copied, setCopied] = useState(false);

  // Sample product data - in real app, this would be fetched based on ID
  const product = {
    id: parseInt(id),
    name: 'Complete Digital Marketing Masterclass',
    description: 'Master digital marketing from scratch with this comprehensive course covering SEO, social media marketing, email marketing, PPC advertising, and analytics.',
    longDescription: `This comprehensive digital marketing masterclass is designed for beginners and intermediate marketers who want to build a successful career in digital marketing. 

The course covers all essential aspects of digital marketing including:
- Search Engine Optimization (SEO)
- Social Media Marketing
- Email Marketing
- Pay-Per-Click (PPC) Advertising
- Content Marketing
- Analytics and Data Analysis
- Conversion Rate Optimization

You'll learn through practical exercises, real-world case studies, and hands-on projects that you can add to your portfolio. By the end of this course, you'll have the skills and knowledge to create and execute successful digital marketing campaigns.`,
    price: 15000,
    originalPrice: 25000,
    commission: 50,
    category: 'courses',
    vendor: {
      name: 'Marketing Pro Academy',
      rating: 4.9,
      totalProducts: 12,
      totalSales: 5678,
      joinDate: '2023-01-15'
    },
    rating: 4.8,
    reviews: 1247,
    sales: 3456,
    affiliates: 234,
    image: '/api/placeholder/600/400',
    gallery: [
      '/api/placeholder/600/400',
      '/api/placeholder/600/400',
      '/api/placeholder/600/400'
    ],
    tags: ['Marketing', 'Digital', 'Business', 'SEO', 'Social Media'],
    featured: true,
    highlights: [
      '20+ hours of video content',
      'Downloadable resources',
      'Certificate of completion',
      'Lifetime access',
      '30-day money-back guarantee'
    ],
    requirements: [
      'Basic computer skills',
      'Internet connection',
      'Willingness to learn'
    ],
    whatYouLearn: [
      'Create effective digital marketing strategies',
      'Optimize websites for search engines',
      'Run successful social media campaigns',
      'Build and manage email marketing campaigns',
      'Analyze marketing data and metrics',
      'Increase website conversions'
    ]
  };

  const reviews = [
    {
      id: 1,
      user: 'Sarah Johnson',
      rating: 5,
      date: '2024-02-10',
      comment: 'Excellent course! The instructor explains everything clearly and the practical exercises are very helpful.',
      helpful: 23,
      verified: true
    },
    {
      id: 2,
      user: 'Mike Chen',
      rating: 5,
      date: '2024-02-08',
      comment: 'This course transformed my understanding of digital marketing. Highly recommended for beginners.',
      helpful: 18,
      verified: true
    },
    {
      id: 3,
      user: 'Aisha Okafor',
      rating: 4,
      date: '2024-02-05',
      comment: 'Great content and well-structured. The only downside is that some sections could be more detailed.',
      helpful: 12,
      verified: true
    }
  ];

  const relatedProducts = [
    {
      id: 2,
      name: 'Advanced SEO Strategies',
      price: 8000,
      commission: 45,
      rating: 4.7,
      image: '/api/placeholder/200/150'
    },
    {
      id: 3,
      name: 'Social Media Marketing Toolkit',
      price: 5000,
      commission: 40,
      rating: 4.6,
      image: '/api/placeholder/200/150'
    },
    {
      id: 4,
      name: 'Email Marketing Mastery',
      price: 6000,
      commission: 35,
      rating: 4.8,
      image: '/api/placeholder/200/150'
    }
  ];

  const generateAffiliateLink = () => {
    if (!user) {
      alert('Please login to generate affiliate links');
      return;
    }

    const baseUrl = window.location.origin;
    const link = `${baseUrl}/product/${product.id}?ref=${user.id}&aff=${user.username}`;
    setAffiliateLink(link);
    setLinkGenerated(true);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(affiliateLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const calculateEarnings = () => {
    return (product.price * product.commission) / 100;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link to="/" className="hover:text-primary">Home</Link>
            <span>/</span>
            <Link to="/products" className="hover:text-primary">Products</Link>
            <span>/</span>
            <span className="text-gray-900">{product.name}</span>
          </div>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Product Header */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge className="bg-primary/10 text-primary">
                        {product.category}
                      </Badge>
                      {product.featured && (
                        <Badge variant="secondary">Featured</Badge>
                      )}
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                      {product.name}
                    </h1>
                    <p className="text-gray-600 mb-4">{product.description}</p>
                    
                    <div className="flex items-center space-x-6 text-sm">
                      <div className="flex items-center">
                        <Star className="h-4 w-4 text-yellow-400 mr-1" />
                        <span className="font-medium">{product.rating}</span>
                        <span className="text-gray-600 ml-1">({product.reviews} reviews)</span>
                      </div>
                      <div className="flex items-center">
                        <Users className="h-4 w-4 text-gray-400 mr-1" />
                        <span>{product.affiliates} affiliates</span>
                      </div>
                      <div className="flex items-center">
                        <TrendingUp className="h-4 w-4 text-gray-400 mr-1" />
                        <span>{product.sales} sales</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      <Heart className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline">
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Product Image */}
                <div className="aspect-video bg-gray-200 rounded-lg flex items-center justify-center mb-6">
                  <Play className="h-16 w-16 text-gray-400" />
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {product.tags.map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Product Details Tabs */}
            <Card>
              <Tabs value={activeTab} onValueChange={setActiveTab}>
                <CardHeader>
                  <TabsList className="grid w-full grid-cols-4">
                    <TabsTrigger value="overview">Overview</TabsTrigger>
                    <TabsTrigger value="curriculum">Curriculum</TabsTrigger>
                    <TabsTrigger value="reviews">Reviews</TabsTrigger>
                    <TabsTrigger value="vendor">Vendor</TabsTrigger>
                  </TabsList>
                </CardHeader>
                
                <CardContent>
                  <TabsContent value="overview" className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-3">About This Course</h3>
                      <p className="text-gray-600 whitespace-pre-line">{product.longDescription}</p>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-3">What You'll Learn</h3>
                      <ul className="space-y-2">
                        {product.whatYouLearn.map((item, index) => (
                          <li key={index} className="flex items-center">
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Requirements</h3>
                      <ul className="space-y-2">
                        {product.requirements.map((item, index) => (
                          <li key={index} className="flex items-center">
                            <AlertCircle className="h-4 w-4 text-blue-500 mr-2" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="curriculum">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Course Content</h3>
                      <div className="space-y-3">
                        {[
                          'Introduction to Digital Marketing',
                          'Search Engine Optimization (SEO)',
                          'Social Media Marketing',
                          'Email Marketing Strategies',
                          'Pay-Per-Click Advertising',
                          'Content Marketing',
                          'Analytics and Measurement',
                          'Final Project and Certification'
                        ].map((module, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center">
                              <Play className="h-4 w-4 text-primary mr-3" />
                              <span>{module}</span>
                            </div>
                            <span className="text-sm text-gray-500">2-3 hours</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="reviews">
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">Customer Reviews</h3>
                        <div className="flex items-center space-x-2">
                          <Star className="h-5 w-5 text-yellow-400" />
                          <span className="font-medium">{product.rating}</span>
                          <span className="text-gray-600">({product.reviews} reviews)</span>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        {reviews.map((review) => (
                          <div key={review.id} className="border rounded-lg p-4">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-2">
                                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                                  <span className="text-primary font-medium text-sm">
                                    {review.user.split(' ').map(n => n[0]).join('')}
                                  </span>
                                </div>
                                <div>
                                  <div className="flex items-center space-x-2">
                                    <span className="font-medium">{review.user}</span>
                                    {review.verified && (
                                      <Badge variant="outline" className="text-xs">
                                        Verified
                                      </Badge>
                                    )}
                                  </div>
                                  <div className="flex items-center space-x-1">
                                    {[...Array(review.rating)].map((_, i) => (
                                      <Star key={i} className="h-3 w-3 text-yellow-400 fill-current" />
                                    ))}
                                    <span className="text-xs text-gray-500 ml-2">{review.date}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <p className="text-gray-600 mb-3">{review.comment}</p>
                            <div className="flex items-center space-x-4 text-sm">
                              <button className="flex items-center space-x-1 text-gray-500 hover:text-primary">
                                <ThumbsUp className="h-3 w-3" />
                                <span>Helpful ({review.helpful})</span>
                              </button>
                              <button className="flex items-center space-x-1 text-gray-500 hover:text-primary">
                                <MessageCircle className="h-3 w-3" />
                                <span>Reply</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="vendor">
                    <div className="space-y-6">
                      <div className="flex items-center space-x-4">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-primary font-bold text-xl">
                            {product.vendor.name.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <h3 className="text-xl font-semibold">{product.vendor.name}</h3>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-400 mr-1" />
                              <span>{product.vendor.rating} rating</span>
                            </div>
                            <span>{product.vendor.totalProducts} products</span>
                            <span>{product.vendor.totalSales} sales</span>
                          </div>
                          <p className="text-sm text-gray-500">Member since {product.vendor.joinDate}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="text-2xl font-bold text-primary">{product.vendor.totalProducts}</div>
                          <div className="text-sm text-gray-600">Products</div>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="text-2xl font-bold text-primary">{product.vendor.totalSales}</div>
                          <div className="text-sm text-gray-600">Sales</div>
                        </div>
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="text-2xl font-bold text-primary">{product.vendor.rating}</div>
                          <div className="text-sm text-gray-600">Rating</div>
                        </div>
                      </div>
                      
                      <Button variant="outline" className="w-full">
                        View All Products
                      </Button>
                    </div>
                  </TabsContent>
                </CardContent>
              </Tabs>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Pricing Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-center">
                  <div className="flex items-center justify-center space-x-2">
                    <span className="text-3xl font-bold text-primary">₦{product.price.toLocaleString()}</span>
                    {product.originalPrice && (
                      <span className="text-lg text-gray-500 line-through">₦{product.originalPrice.toLocaleString()}</span>
                    )}
                  </div>
                  <div className="text-lg text-green-600 font-medium mt-2">
                    {product.commission}% Commission
                  </div>
                  <div className="text-sm text-gray-600">
                    You earn: ₦{calculateEarnings().toLocaleString()} per sale
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {product.highlights.map((highlight, index) => (
                    <div key={index} className="flex items-center">
                      <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                      <span className="text-sm">{highlight}</span>
                    </div>
                  ))}
                </div>
                
                {user ? (
                  <div className="space-y-3">
                    {!linkGenerated ? (
                      <Button onClick={generateAffiliateLink} className="w-full">
                        <DollarSign className="h-4 w-4 mr-2" />
                        Generate Affiliate Link
                      </Button>
                    ) : (
                      <div className="space-y-2">
                        <div className="p-3 bg-gray-50 rounded-lg">
                          <div className="text-xs text-gray-600 mb-1">Your Affiliate Link:</div>
                          <div className="text-sm font-mono break-all">{affiliateLink}</div>
                        </div>
                        <Button onClick={copyToClipboard} variant="outline" className="w-full">
                          <Copy className="h-4 w-4 mr-2" />
                          {copied ? 'Copied!' : 'Copy Link'}
                        </Button>
                      </div>
                    )}
                    
                    <Button variant="outline" className="w-full">
                      <Eye className="h-4 w-4 mr-2" />
                      Preview Product
                    </Button>
                    
                    <Button variant="outline" className="w-full">
                      <Download className="h-4 w-4 mr-2" />
                      Download Assets
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        Login to generate affiliate links and start earning commissions.
                      </AlertDescription>
                    </Alert>
                    <Link to="/login">
                      <Button className="w-full">
                        Login to Promote
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Related Products */}
            <Card>
              <CardHeader>
                <CardTitle>Related Products</CardTitle>
                <CardDescription>Other products you might like</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {relatedProducts.map((relatedProduct) => (
                  <Link key={relatedProduct.id} to={`/product/${relatedProduct.id}`}>
                    <div className="flex items-center space-x-3 p-3 border rounded-lg hover:shadow-md transition-shadow">
                      <div className="w-16 h-12 bg-gray-200 rounded flex items-center justify-center flex-shrink-0">
                        <span className="text-xs text-gray-500">Image</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-sm line-clamp-2">{relatedProduct.name}</h4>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-primary font-medium">₦{relatedProduct.price.toLocaleString()}</span>
                          <div className="flex items-center">
                            <Star className="h-3 w-3 text-yellow-400 mr-1" />
                            <span className="text-xs">{relatedProduct.rating}</span>
                          </div>
                        </div>
                        <div className="text-xs text-green-600">{relatedProduct.commission}% commission</div>
                      </div>
                    </div>
                  </Link>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;

