import React, { useState, useContext } from 'react';
import { AuthContext } from '../App';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  DollarSign,
  Users,
  Package,
  TrendingUp,
  Eye,
  Check,
  X,
  Edit,
  Trash2,
  Plus,
  Download,
  Calendar,
  Filter,
  Search,
  Star,
  CheckCircle,
  AlertCircle,
  Clock,
  Shield,
  FileText,
  Settings,
  Activity,
  UserCheck,
  UserX,
  AlertTriangle
} from 'lucide-react';

const AdminDashboard = () => {
  const { user } = useContext(AuthContext);
  const [selectedPeriod, setSelectedPeriod] = useState('7d');

  // Sample data - replace with real API calls
  const stats = {
    totalUsers: 15847,
    totalVendors: 1234,
    totalAffiliates: 8956,
    totalRevenue: 2847500,
    platformCommission: 1138900,
    pendingApprovals: 23,
    activeProducts: 456,
    pendingKYC: 12
  };

  const platformData = [
    { date: '2024-01-01', users: 120, revenue: 45000, transactions: 89 },
    { date: '2024-01-02', users: 98, revenue: 38000, transactions: 76 },
    { date: '2024-01-03', users: 156, revenue: 52000, transactions: 104 },
    { date: '2024-01-04', users: 134, revenue: 48000, transactions: 92 },
    { date: '2024-01-05', users: 178, revenue: 61000, transactions: 118 },
    { date: '2024-01-06', users: 145, revenue: 49000, transactions: 95 },
    { date: '2024-01-07', users: 189, revenue: 67000, transactions: 128 }
  ];

  const pendingProducts = [
    { 
      id: 1, 
      name: 'Advanced React Course', 
      vendor: 'John Developer', 
      price: 2500, 
      commission: 55, 
      category: 'Course',
      submittedDate: '2024-02-10',
      status: 'pending'
    },
    { 
      id: 2, 
      name: 'E-commerce Templates', 
      vendor: 'Design Studio', 
      price: 800, 
      commission: 40, 
      category: 'Templates',
      submittedDate: '2024-02-12',
      status: 'pending'
    },
    { 
      id: 3, 
      name: 'Marketing Automation Tools', 
      vendor: 'Tech Solutions', 
      price: 1500, 
      commission: 50, 
      category: 'Software',
      submittedDate: '2024-02-13',
      status: 'pending'
    }
  ];

  const pendingKYC = [
    {
      id: 1,
      name: 'Sarah Johnson',
      email: 'sarah@example.com',
      type: 'vendor',
      submittedDate: '2024-02-10',
      documents: ['ID Card', 'Bank Statement', 'Business Registration'],
      status: 'pending'
    },
    {
      id: 2,
      name: 'Mike Chen',
      email: 'mike@example.com',
      type: 'vendor',
      submittedDate: '2024-02-11',
      documents: ['Passport', 'Utility Bill', 'Tax Certificate'],
      status: 'pending'
    },
    {
      id: 3,
      name: 'Lisa Brown',
      email: 'lisa@example.com',
      type: 'affiliate',
      submittedDate: '2024-02-12',
      documents: ['Driver License', 'Bank Statement'],
      status: 'pending'
    }
  ];

  const recentUsers = [
    { id: 1, name: 'Alice Cooper', email: 'alice@example.com', type: 'affiliate', joinDate: '2024-02-15', status: 'active' },
    { id: 2, name: 'Bob Wilson', email: 'bob@example.com', type: 'vendor', joinDate: '2024-02-14', status: 'pending' },
    { id: 3, name: 'Carol Davis', email: 'carol@example.com', type: 'affiliate', joinDate: '2024-02-13', status: 'active' },
    { id: 4, name: 'David Miller', email: 'david@example.com', type: 'vendor', joinDate: '2024-02-12', status: 'active' }
  ];

  const topPerformers = [
    { id: 1, name: 'Sarah Johnson', type: 'affiliate', sales: 156, revenue: 234000, commission: 117000 },
    { id: 2, name: 'Tech Solutions', type: 'vendor', sales: 89, revenue: 445000, commission: 178000 },
    { id: 3, name: 'Mike Chen', type: 'affiliate', sales: 134, revenue: 201000, commission: 100500 },
    { id: 4, name: 'Design Studio', type: 'vendor', sales: 67, revenue: 335000, commission: 134000 }
  ];

  const [blogPost, setBlogPost] = useState({
    title: '',
    content: '',
    category: '',
    featured: false
  });

  const handleProductApproval = (productId, action) => {
    console.log(`${action} product ${productId}`);
    // Handle product approval/rejection
  };

  const handleKYCApproval = (kycId, action) => {
    console.log(`${action} KYC ${kycId}`);
    // Handle KYC approval/rejection
  };

  const handleBlogSubmit = (e) => {
    e.preventDefault();
    console.log('Publishing blog post:', blogPost);
    // Handle blog post creation
    setBlogPost({
      title: '',
      content: '',
      category: '',
      featured: false
    });
  };

  const userTypeColors = {
    admin: 'bg-red-100 text-red-800',
    vendor: 'bg-blue-100 text-blue-800',
    affiliate: 'bg-green-100 text-green-800'
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600">Platform overview and management tools</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +12.5% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Platform Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₦{stats.platformCommission.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                40% of total ₦{stats.totalRevenue.toLocaleString()}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pendingApprovals}</div>
              <p className="text-xs text-muted-foreground">
                Products & KYC reviews
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Products</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeProducts}</div>
              <p className="text-xs text-muted-foreground">
                Across all vendors
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="kyc">KYC</TabsTrigger>
            <TabsTrigger value="blog">Blog</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Platform Growth */}
              <Card>
                <CardHeader>
                  <CardTitle>Platform Growth</CardTitle>
                  <CardDescription>User registrations and revenue trends</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={platformData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="users" stroke="#8884d8" strokeWidth={2} name="New Users" />
                      <Line type="monotone" dataKey="transactions" stroke="#82ca9d" strokeWidth={2} name="Transactions" />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Top Performers */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Performers</CardTitle>
                  <CardDescription>Highest earning users this month</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topPerformers.map((performer) => (
                      <div key={performer.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                            <span className="text-primary font-medium">
                              {performer.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div>
                            <h4 className="font-medium">{performer.name}</h4>
                            <div className="flex items-center space-x-2">
                              <Badge className={userTypeColors[performer.type]}>
                                {performer.type}
                              </Badge>
                              <span className="text-sm text-gray-600">{performer.sales} sales</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">₦{performer.revenue.toLocaleString()}</div>
                          <p className="text-sm text-gray-600">₦{performer.commission.toLocaleString()} commission</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent User Registrations</CardTitle>
                <CardDescription>Latest users who joined the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-primary font-medium">
                            {user.name.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-medium">{user.name}</h4>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <p className="text-xs text-gray-500">Joined {user.joinDate}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={userTypeColors[user.type]}>
                          {user.type}
                        </Badge>
                        <Badge variant={user.status === 'active' ? 'default' : 'secondary'}>
                          {user.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>Manage platform users and their permissions</CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline">
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                    <Button>
                      <Plus className="h-4 w-4 mr-2" />
                      Add User
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-6">
                  <div className="flex-1">
                    <Input placeholder="Search users..." />
                  </div>
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {recentUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-primary font-medium">
                            {user.name.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-medium">{user.name}</h4>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <p className="text-xs text-gray-500">Joined {user.joinDate}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge className={userTypeColors[user.type]}>
                          {user.type}
                        </Badge>
                        <Badge variant={user.status === 'active' ? 'default' : 'secondary'}>
                          {user.status}
                        </Badge>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <UserX className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Product Approvals</CardTitle>
                <CardDescription>Review and approve vendor product submissions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingProducts.map((product) => (
                    <div key={product.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-lg">{product.name}</h4>
                          <p className="text-sm text-gray-600">by {product.vendor}</p>
                          <p className="text-xs text-gray-500">Submitted {product.submittedDate}</p>
                        </div>
                        <Badge variant="secondary">{product.status}</Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                        <div>
                          <span className="text-gray-600">Price:</span>
                          <div className="font-medium">₦{product.price}</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Commission:</span>
                          <div className="font-medium">{product.commission}%</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Category:</span>
                          <div className="font-medium">{product.category}</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Status:</span>
                          <div className="font-medium">{product.status}</div>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          onClick={() => handleProductApproval(product.id, 'approve')}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <Check className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleProductApproval(product.id, 'reject')}
                        >
                          <X className="h-4 w-4 mr-2" />
                          Reject
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4 mr-2" />
                          Review
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* KYC Tab */}
          <TabsContent value="kyc" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>KYC Verification</CardTitle>
                <CardDescription>Review and approve user identity verification documents</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingKYC.map((kyc) => (
                    <div key={kyc.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-medium text-lg">{kyc.name}</h4>
                          <p className="text-sm text-gray-600">{kyc.email}</p>
                          <p className="text-xs text-gray-500">Submitted {kyc.submittedDate}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={userTypeColors[kyc.type]}>
                            {kyc.type}
                          </Badge>
                          <Badge variant="secondary">{kyc.status}</Badge>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <span className="text-sm text-gray-600">Documents submitted:</span>
                        <div className="flex flex-wrap gap-2 mt-1">
                          {kyc.documents.map((doc, index) => (
                            <Badge key={index} variant="outline">{doc}</Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          onClick={() => handleKYCApproval(kyc.id, 'approve')}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <UserCheck className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          onClick={() => handleKYCApproval(kyc.id, 'reject')}
                        >
                          <UserX className="h-4 w-4 mr-2" />
                          Reject
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4 mr-2" />
                          Review Documents
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Blog Tab */}
          <TabsContent value="blog" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Blog Management</CardTitle>
                <CardDescription>Create and manage blog content for the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBlogSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="blogTitle">Post Title</Label>
                    <Input
                      id="blogTitle"
                      value={blogPost.title}
                      onChange={(e) => setBlogPost({...blogPost, title: e.target.value})}
                      placeholder="Enter blog post title"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="blogCategory">Category</Label>
                    <Input
                      id="blogCategory"
                      value={blogPost.category}
                      onChange={(e) => setBlogPost({...blogPost, category: e.target.value})}
                      placeholder="e.g., Tips, News, Updates"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="blogContent">Content</Label>
                    <Textarea
                      id="blogContent"
                      value={blogPost.content}
                      onChange={(e) => setBlogPost({...blogPost, content: e.target.value})}
                      placeholder="Write your blog post content here..."
                      rows={10}
                      required
                    />
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="featured"
                      checked={blogPost.featured}
                      onChange={(e) => setBlogPost({...blogPost, featured: e.target.checked})}
                      className="rounded"
                    />
                    <Label htmlFor="featured">Feature this post</Label>
                  </div>

                  <div className="flex space-x-4">
                    <Button type="submit">
                      <FileText className="h-4 w-4 mr-2" />
                      Publish Post
                    </Button>
                    <Button type="button" variant="outline">
                      Save Draft
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Platform Revenue</CardTitle>
                  <CardDescription>Total revenue and commission breakdown</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={platformData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="revenue" fill="#8884d8" name="Revenue" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Growth</CardTitle>
                  <CardDescription>New user registrations over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={platformData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="users" stroke="#82ca9d" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Platform Statistics</CardTitle>
                <CardDescription>Key metrics and performance indicators</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{stats.totalVendors}</div>
                    <p className="text-sm text-gray-600">Total Vendors</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{stats.totalAffiliates}</div>
                    <p className="text-sm text-gray-600">Total Affiliates</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{stats.activeProducts}</div>
                    <p className="text-sm text-gray-600">Active Products</p>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{stats.pendingKYC}</div>
                    <p className="text-sm text-gray-600">Pending KYC</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AdminDashboard;

