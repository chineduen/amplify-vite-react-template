import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Star, 
  Search, 
  Filter, 
  Grid, 
  List, 
  TrendingUp, 
  Users, 
  DollarSign,
  Eye,
  Heart,
  Share2
} from 'lucide-react';

const ProductCatalog = () => {
  const [viewMode, setViewMode] = useState('grid');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('popular');

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'courses', label: 'Online Courses' },
    { value: 'software', label: 'Software & Tools' },
    { value: 'templates', label: 'Templates & Designs' },
    { value: 'ebooks', label: 'E-books' },
    { value: 'services', label: 'Digital Services' }
  ];

  const products = [
    {
      id: 1,
      name: 'Complete Digital Marketing Masterclass',
      description: 'Learn digital marketing from scratch with hands-on projects and real-world case studies.',
      price: 15000,
      commission: 50,
      category: 'courses',
      vendor: 'Marketing Pro Academy',
      rating: 4.8,
      reviews: 1247,
      sales: 3456,
      affiliates: 234,
      image: '/api/placeholder/300/200',
      tags: ['Marketing', 'Digital', 'Business'],
      featured: true
    },
    {
      id: 2,
      name: 'Web Development Bundle',
      description: 'Complete web development course with HTML, CSS, JavaScript, React, and Node.js.',
      price: 12000,
      commission: 60,
      category: 'courses',
      vendor: 'Code Academy Plus',
      rating: 4.9,
      reviews: 892,
      sales: 2134,
      affiliates: 156,
      image: '/api/placeholder/300/200',
      tags: ['Programming', 'Web Development', 'JavaScript'],
      featured: false
    },
    {
      id: 3,
      name: 'SEO Tools & Analytics Suite',
      description: 'Professional SEO tools for keyword research, competitor analysis, and rank tracking.',
      price: 8000,
      commission: 45,
      category: 'software',
      vendor: 'SEO Masters',
      rating: 4.6,
      reviews: 567,
      sales: 1789,
      affiliates: 98,
      image: '/api/placeholder/300/200',
      tags: ['SEO', 'Analytics', 'Tools'],
      featured: true
    },
    {
      id: 4,
      name: 'Premium Social Media Templates',
      description: 'Over 500 professionally designed templates for Instagram, Facebook, and LinkedIn.',
      price: 3500,
      commission: 30,
      category: 'templates',
      vendor: 'Design Studio Pro',
      rating: 4.7,
      reviews: 1023,
      sales: 4567,
      affiliates: 312,
      image: '/api/placeholder/300/200',
      tags: ['Design', 'Social Media', 'Templates'],
      featured: false
    },
    {
      id: 5,
      name: 'E-commerce Business Guide',
      description: 'Complete guide to starting and scaling your e-commerce business from zero to millions.',
      price: 5000,
      commission: 40,
      category: 'ebooks',
      vendor: 'Business Experts',
      rating: 4.5,
      reviews: 789,
      sales: 2345,
      affiliates: 167,
      image: '/api/placeholder/300/200',
      tags: ['E-commerce', 'Business', 'Entrepreneurship'],
      featured: false
    },
    {
      id: 6,
      name: 'AI Content Creation Tools',
      description: 'Advanced AI-powered tools for creating blog posts, social media content, and marketing copy.',
      price: 10000,
      commission: 55,
      category: 'software',
      vendor: 'AI Solutions Inc',
      rating: 4.8,
      reviews: 456,
      sales: 1234,
      affiliates: 89,
      image: '/api/placeholder/300/200',
      tags: ['AI', 'Content', 'Automation'],
      featured: true
    }
  ];

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'rating':
        return b.rating - a.rating;
      case 'commission':
        return b.commission - a.commission;
      case 'sales':
        return b.sales - a.sales;
      default: // popular
        return b.sales - a.sales;
    }
  });

  const ProductCard = ({ product }) => (
    <Card className="group hover:shadow-lg transition-shadow duration-200">
      <div className="relative">
        <div className="aspect-video bg-gray-200 rounded-t-lg flex items-center justify-center">
          <span className="text-gray-500">Product Image</span>
        </div>
        {product.featured && (
          <Badge className="absolute top-2 left-2 bg-primary">
            Featured
          </Badge>
        )}
        <div className="absolute top-2 right-2 flex space-x-1">
          <Button size="sm" variant="ghost" className="h-8 w-8 p-0 bg-white/80 hover:bg-white">
            <Heart className="h-4 w-4" />
          </Button>
          <Button size="sm" variant="ghost" className="h-8 w-8 p-0 bg-white/80 hover:bg-white">
            <Share2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg line-clamp-2 group-hover:text-primary transition-colors">
              {product.name}
            </CardTitle>
            <p className="text-sm text-gray-600 mt-1">by {product.vendor}</p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <CardDescription className="line-clamp-2 mb-3">
          {product.description}
        </CardDescription>
        
        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-400 mr-1" />
            <span>{product.rating}</span>
            <span className="ml-1">({product.reviews})</span>
          </div>
          <div className="flex items-center">
            <Users className="h-4 w-4 mr-1" />
            <span>{product.affiliates} affiliates</span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {product.tags.slice(0, 3).map((tag, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <div className="text-2xl font-bold text-primary">₦{product.price.toLocaleString()}</div>
            <div className="text-sm text-green-600 font-medium">{product.commission}% commission</div>
          </div>
          <div className="flex space-x-2">
            <Link to={`/product/${product.id}`}>
              <Button size="sm" variant="outline">
                <Eye className="h-4 w-4 mr-2" />
                View
              </Button>
            </Link>
            <Button size="sm">
              Promote
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const ProductListItem = ({ product }) => (
    <Card className="group hover:shadow-md transition-shadow duration-200">
      <CardContent className="p-4">
        <div className="flex items-center space-x-4">
          <div className="w-24 h-16 bg-gray-200 rounded flex items-center justify-center flex-shrink-0">
            <span className="text-xs text-gray-500">Image</span>
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-semibold text-lg group-hover:text-primary transition-colors line-clamp-1">
                  {product.name}
                </h3>
                <p className="text-sm text-gray-600 mb-1">by {product.vendor}</p>
                <p className="text-sm text-gray-600 line-clamp-2 mb-2">{product.description}</p>
                
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 mr-1" />
                    <span>{product.rating} ({product.reviews})</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-1" />
                    <span>{product.affiliates} affiliates</span>
                  </div>
                  <div className="flex items-center">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    <span>{product.sales} sales</span>
                  </div>
                </div>
              </div>
              
              <div className="text-right ml-4">
                <div className="text-xl font-bold text-primary">₦{product.price.toLocaleString()}</div>
                <div className="text-sm text-green-600 font-medium">{product.commission}% commission</div>
                <div className="flex space-x-2 mt-2">
                  <Link to={`/product/${product.id}`}>
                    <Button size="sm" variant="outline">
                      View
                    </Button>
                  </Link>
                  <Button size="sm">
                    Promote
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Product Catalog</h1>
          <p className="text-gray-600">Discover and promote high-quality digital products</p>
        </div>

        {/* Filters and Search */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search products, vendors, or tags..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="flex gap-4">
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        {category.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popular">Most Popular</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="commission">Highest Commission</SelectItem>
                    <SelectItem value="price-low">Price: Low to High</SelectItem>
                    <SelectItem value="price-high">Price: High to Low</SelectItem>
                    <SelectItem value="sales">Most Sales</SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="flex border rounded-md">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                    className="rounded-r-none"
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'ghost'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                    className="rounded-l-none"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Summary */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-gray-600">
            Showing {sortedProducts.length} of {products.length} products
          </p>
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <span className="text-sm text-gray-600">
              {selectedCategory !== 'all' && `Category: ${categories.find(c => c.value === selectedCategory)?.label}`}
              {searchTerm && ` • Search: "${searchTerm}"`}
            </span>
          </div>
        </div>

        {/* Products Grid/List */}
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {sortedProducts.map((product) => (
              <ProductListItem key={product.id} product={product} />
            ))}
          </div>
        )}

        {/* No Results */}
        {sortedProducts.length === 0 && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
            <p className="text-gray-600 mb-4">
              Try adjusting your search terms or filters to find what you're looking for.
            </p>
            <Button onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
            }}>
              Clear Filters
            </Button>
          </div>
        )}

        {/* Load More */}
        {sortedProducts.length > 0 && (
          <div className="text-center mt-12">
            <Button variant="outline" size="lg">
              Load More Products
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductCatalog;

