import React, { useState, useContext } from 'react';
import { AuthContext } from '../App';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import {
  DollarSign,
  Package,
  Users,
  TrendingUp,
  Eye,
  Edit,
  Trash2,
  Plus,
  Download,
  Calendar,
  Filter,
  Search,
  Star,
  CheckCircle,
  AlertCircle,
  Clock,
  ShoppingCart,
  BarChart3,
  Settings
} from 'lucide-react';

const VendorDashboard = () => {
  const { user } = useContext(AuthContext);
  const [selectedPeriod, setSelectedPeriod] = useState('7d');
  const [showAddProduct, setShowAddProduct] = useState(false);

  // Sample data - replace with real API calls
  const stats = {
    totalRevenue: 125750,
    thisMonthRevenue: 35200,
    totalProducts: 12,
    activeProducts: 10,
    totalSales: 342,
    activeAffiliates: 89,
    conversionRate: 4.2,
    avgOrderValue: 368
  };

  const salesData = [
    { date: '2024-01-01', sales: 4200, affiliates: 2800 },
    { date: '2024-01-02', sales: 3800, affiliates: 2100 },
    { date: '2024-01-03', sales: 5200, affiliates: 3400 },
    { date: '2024-01-04', sales: 4600, affiliates: 2900 },
    { date: '2024-01-05', sales: 5800, affiliates: 3800 },
    { date: '2024-01-06', sales: 4900, affiliates: 3200 },
    { date: '2024-01-07', sales: 6100, affiliates: 4000 }
  ];

  const products = [
    { 
      id: 1, 
      name: 'Digital Marketing Masterclass', 
      price: 1500, 
      commission: 50, 
      sales: 89, 
      revenue: 133500, 
      affiliates: 34, 
      status: 'active',
      category: 'Course',
      rating: 4.8
    },
    { 
      id: 2, 
      name: 'Web Development Bundle', 
      price: 800, 
      commission: 60, 
      sales: 67, 
      revenue: 53600, 
      affiliates: 28, 
      status: 'active',
      category: 'Software',
      rating: 4.6
    },
    { 
      id: 3, 
      name: 'SEO Tools Package', 
      price: 600, 
      commission: 45, 
      sales: 45, 
      revenue: 27000, 
      affiliates: 19, 
      status: 'pending',
      category: 'Tools',
      rating: 4.7
    },
    { 
      id: 4, 
      name: 'Social Media Templates', 
      price: 250, 
      commission: 30, 
      sales: 123, 
      revenue: 30750, 
      affiliates: 42, 
      status: 'active',
      category: 'Templates',
      rating: 4.5
    }
  ];

  const topAffiliates = [
    { id: 1, name: 'Sarah Johnson', sales: 23, revenue: 34500, commission: 17250, rating: 4.9 },
    { id: 2, name: 'Mike Chen', sales: 19, revenue: 28500, commission: 14250, rating: 4.8 },
    { id: 3, name: 'Lisa Brown', sales: 16, revenue: 24000, commission: 12000, rating: 4.7 },
    { id: 4, name: 'John Smith', sales: 14, revenue: 21000, commission: 10500, rating: 4.6 }
  ];

  const recentOrders = [
    { id: 1, product: 'Digital Marketing Masterclass', customer: 'Alice Cooper', amount: 1500, affiliate: 'Sarah Johnson', date: '2024-02-15', status: 'completed' },
    { id: 2, product: 'Web Development Bundle', customer: 'Bob Wilson', amount: 800, affiliate: 'Mike Chen', date: '2024-02-14', status: 'completed' },
    { id: 3, product: 'SEO Tools Package', customer: 'Carol Davis', amount: 600, affiliate: 'Lisa Brown', date: '2024-02-13', status: 'processing' },
    { id: 4, product: 'Social Media Templates', customer: 'David Miller', amount: 250, affiliate: 'John Smith', date: '2024-02-12', status: 'completed' }
  ];

  const [newProduct, setNewProduct] = useState({
    name: '',
    description: '',
    price: '',
    commission: '',
    category: '',
    type: 'digital'
  });

  const handleProductSubmit = (e) => {
    e.preventDefault();
    // Handle product creation
    console.log('Creating product:', newProduct);
    setShowAddProduct(false);
    setNewProduct({
      name: '',
      description: '',
      price: '',
      commission: '',
      category: '',
      type: 'digital'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Vendor Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user.name}! Manage your products and track performance.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₦{stats.totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                +18.2% from last month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Products</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeProducts}</div>
              <p className="text-xs text-muted-foreground">
                {stats.totalProducts} total products
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Affiliates</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeAffiliates}</div>
              <p className="text-xs text-muted-foreground">
                +12 new this month
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.conversionRate}%</div>
              <p className="text-xs text-muted-foreground">
                +0.3% from last month
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="affiliates">Affiliates</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Sales Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Sales Performance</CardTitle>
                  <CardDescription>Direct sales vs affiliate-driven sales</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="sales" fill="#8884d8" name="Direct Sales" />
                      <Bar dataKey="affiliates" fill="#82ca9d" name="Affiliate Sales" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              {/* Top Products */}
              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Products</CardTitle>
                  <CardDescription>Your best-selling products</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {products.slice(0, 4).map((product) => (
                      <div key={product.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium">{product.name}</h4>
                          <p className="text-sm text-gray-600">{product.sales} sales • {product.commission}% commission</p>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">₦{product.revenue.toLocaleString()}</div>
                          <div className="flex items-center">
                            <Star className="h-3 w-3 text-yellow-400 mr-1" />
                            <span className="text-xs">{product.rating}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Orders */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Orders</CardTitle>
                <CardDescription>Latest customer purchases</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentOrders.map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-2 h-2 rounded-full ${
                          order.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500'
                        }`} />
                        <div>
                          <p className="font-medium">{order.product}</p>
                          <p className="text-sm text-gray-600">Customer: {order.customer}</p>
                          <p className="text-sm text-gray-600">Affiliate: {order.affiliate}</p>
                          <p className="text-xs text-gray-500">{order.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">₦{order.amount}</div>
                        <Badge variant={order.status === 'completed' ? 'default' : 'secondary'}>
                          {order.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Product Management</CardTitle>
                    <CardDescription>Manage your product catalog and settings</CardDescription>
                  </div>
                  <Button onClick={() => setShowAddProduct(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Product
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-6">
                  <div className="flex-1">
                    <Input placeholder="Search products..." />
                  </div>
                  <Button variant="outline">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {products.map((product) => (
                    <div key={product.id} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <h4 className="font-medium text-lg">{product.name}</h4>
                          <Badge variant={product.status === 'active' ? 'default' : 'secondary'}>
                            {product.status}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button size="sm" variant="outline">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Price:</span>
                          <div className="font-medium">₦{product.price}</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Commission:</span>
                          <div className="font-medium">{product.commission}%</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Sales:</span>
                          <div className="font-medium">{product.sales}</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Revenue:</span>
                          <div className="font-medium">₦{product.revenue.toLocaleString()}</div>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center space-x-4 text-sm text-gray-600">
                          <span>{product.affiliates} affiliates promoting</span>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 mr-1" />
                            <span>{product.rating} rating</span>
                          </div>
                        </div>
                        <Badge variant="outline">{product.category}</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Add Product Modal */}
            {showAddProduct && (
              <Card>
                <CardHeader>
                  <CardTitle>Add New Product</CardTitle>
                  <CardDescription>Create a new product for your affiliates to promote</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleProductSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="productName">Product Name</Label>
                        <Input
                          id="productName"
                          value={newProduct.name}
                          onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                          placeholder="Enter product name"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="productCategory">Category</Label>
                        <Select value={newProduct.category} onValueChange={(value) => setNewProduct({...newProduct, category: value})}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="course">Course</SelectItem>
                            <SelectItem value="software">Software</SelectItem>
                            <SelectItem value="tools">Tools</SelectItem>
                            <SelectItem value="templates">Templates</SelectItem>
                            <SelectItem value="ebook">E-book</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="productDescription">Description</Label>
                      <Textarea
                        id="productDescription"
                        value={newProduct.description}
                        onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                        placeholder="Describe your product"
                        rows={3}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="productPrice">Price (₦)</Label>
                        <Input
                          id="productPrice"
                          type="number"
                          value={newProduct.price}
                          onChange={(e) => setNewProduct({...newProduct, price: e.target.value})}
                          placeholder="0"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="productCommission">Commission (%)</Label>
                        <Input
                          id="productCommission"
                          type="number"
                          min="30"
                          max="70"
                          value={newProduct.commission}
                          onChange={(e) => setNewProduct({...newProduct, commission: e.target.value})}
                          placeholder="50"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="productType">Product Type</Label>
                        <Select value={newProduct.type} onValueChange={(value) => setNewProduct({...newProduct, type: value})}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="digital">Digital</SelectItem>
                            <SelectItem value="physical">Physical</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="flex space-x-4">
                      <Button type="button" variant="outline" onClick={() => setShowAddProduct(false)}>
                        Cancel
                      </Button>
                      <Button type="submit">
                        Create Product
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Affiliates Tab */}
          <TabsContent value="affiliates" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Affiliates</CardTitle>
                <CardDescription>Your best performing affiliate partners</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topAffiliates.map((affiliate) => (
                    <div key={affiliate.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <span className="text-primary font-medium">
                            {affiliate.name.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-medium">{affiliate.name}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>{affiliate.sales} sales</span>
                            <div className="flex items-center">
                              <Star className="h-3 w-3 text-yellow-400 mr-1" />
                              <span>{affiliate.rating}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">₦{affiliate.revenue.toLocaleString()}</div>
                        <p className="text-sm text-gray-600">₦{affiliate.commission.toLocaleString()} commission</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Order Management</CardTitle>
                    <CardDescription>Track and manage customer orders</CardDescription>
                  </div>
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentOrders.map((order) => (
                    <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${
                          order.status === 'completed' ? 'bg-green-500' : 'bg-yellow-500'
                        }`} />
                        <div>
                          <h4 className="font-medium">{order.product}</h4>
                          <p className="text-sm text-gray-600">Customer: {order.customer}</p>
                          <p className="text-sm text-gray-600">Affiliate: {order.affiliate}</p>
                          <p className="text-xs text-gray-500">{order.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">₦{order.amount}</div>
                        <Badge variant={order.status === 'completed' ? 'default' : 'secondary'}>
                          {order.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Trends</CardTitle>
                  <CardDescription>Track your revenue over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={salesData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="sales" stroke="#8884d8" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Performance Metrics</CardTitle>
                  <CardDescription>Key performance indicators</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium">Average Order Value</span>
                    <span className="text-lg font-bold">₦{stats.avgOrderValue}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium">Conversion Rate</span>
                    <span className="text-lg font-bold">{stats.conversionRate}%</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium">Total Sales</span>
                    <span className="text-lg font-bold">{stats.totalSales}</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium">Active Affiliates</span>
                    <span className="text-lg font-bold">{stats.activeAffiliates}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default VendorDashboard;

