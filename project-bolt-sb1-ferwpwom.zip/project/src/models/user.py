from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timezone
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
import json
from enum import Enum

db = SQLAlchemy()

class UserRole(Enum):
    ADMIN = "admin"
    VENDOR = "vendor"
    AFFILIATE = "affiliate"

class ProductStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    INACTIVE = "inactive"

class ProductType(Enum):
    DIGITAL = "digital"
    PHYSICAL = "physical"

class TransactionStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class WithdrawalStatus(Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

class KYCStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

# User Model
class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    role = db.Column(db.Enum(UserRole), nullable=False, default=UserRole.AFFILIATE)
    
    # Affiliate specific fields
    affiliate_id = db.Column(db.String(20), unique=True, nullable=True)
    referrer_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=True)
    referral_code = db.Column(db.String(20), unique=True, nullable=True)
    
    # Account status
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    email_verified = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    referrer = db.relationship('User', remote_side=[id], backref='referrals')
    products = db.relationship('Product', backref='vendor', lazy=True)
    bank_accounts = db.relationship('BankAccount', backref='user', lazy=True)
    kyc_documents = db.relationship('KYCDocument', backref='user', lazy=True)
    transactions = db.relationship('Transaction', foreign_keys='Transaction.user_id', backref='user', lazy=True)
    commissions_earned = db.relationship('Commission', foreign_keys='Commission.affiliate_id', backref='affiliate', lazy=True)
    withdrawals = db.relationship('Withdrawal', backref='user', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def generate_affiliate_id(self):
        if not self.affiliate_id:
            self.affiliate_id = f"HSK{str(uuid.uuid4())[:8].upper()}"
    
    def generate_referral_code(self):
        if not self.referral_code:
            self.referral_code = f"{self.username[:4].upper()}{str(uuid.uuid4())[:6].upper()}"
    
    def get_balance(self):
        """Calculate user's current balance from commissions"""
        total_earned = db.session.query(db.func.sum(Commission.amount)).filter(
            Commission.affiliate_id == self.id,
            Commission.status == 'completed'
        ).scalar() or 0
        
        total_withdrawn = db.session.query(db.func.sum(Withdrawal.amount)).filter(
            Withdrawal.user_id == self.id,
            Withdrawal.status.in_(['completed', 'processing'])
        ).scalar() or 0
        
        return total_earned - total_withdrawn
    
    def get_referral_tree(self, level=1, max_level=2):
        """Get referral tree up to specified level"""
        if level > max_level:
            return []
        
        direct_referrals = User.query.filter_by(referrer_id=self.id).all()
        tree = []
        
        for referral in direct_referrals:
            referral_data = {
                'user': referral,
                'level': level,
                'children': referral.get_referral_tree(level + 1, max_level)
            }
            tree.append(referral_data)
        
        return tree
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'phone': self.phone,
            'role': self.role.value,
            'affiliate_id': self.affiliate_id,
            'referral_code': self.referral_code,
            'is_active': self.is_active,
            'is_verified': self.is_verified,
            'email_verified': self.email_verified,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'balance': self.get_balance()
        }

# Product Model
class Product(db.Model):
    __tablename__ = 'products'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    vendor_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    
    # Product details
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    short_description = db.Column(db.String(500), nullable=True)
    price = db.Column(db.Numeric(10, 2), nullable=False)
    currency = db.Column(db.String(3), default='NGN')
    
    # Product type and category
    product_type = db.Column(db.Enum(ProductType), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    tags = db.Column(db.Text, nullable=True)  # JSON array of tags
    
    # Commission settings
    commission_percentage = db.Column(db.Numeric(5, 2), nullable=False, default=50.00)  # 50-70%
    
    # Product status and visibility
    status = db.Column(db.Enum(ProductStatus), default=ProductStatus.PENDING)
    is_active = db.Column(db.Boolean, default=True)
    is_featured = db.Column(db.Boolean, default=False)
    
    # Digital product specific
    download_url = db.Column(db.String(500), nullable=True)
    file_size = db.Column(db.BigInteger, nullable=True)
    
    # Physical product specific
    weight = db.Column(db.Numeric(8, 2), nullable=True)
    dimensions = db.Column(db.String(100), nullable=True)
    shipping_required = db.Column(db.Boolean, default=False)
    
    # SEO and marketing
    slug = db.Column(db.String(200), unique=True, nullable=True)
    meta_title = db.Column(db.String(200), nullable=True)
    meta_description = db.Column(db.String(500), nullable=True)
    
    # Analytics
    views_count = db.Column(db.Integer, default=0)
    sales_count = db.Column(db.Integer, default=0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    approved_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    affiliate_links = db.relationship('AffiliateLink', backref='product', lazy=True)
    transactions = db.relationship('Transaction', backref='product', lazy=True)
    reviews = db.relationship('ProductReview', backref='product', lazy=True)
    
    def get_tags_list(self):
        if self.tags:
            return json.loads(self.tags)
        return []
    
    def set_tags_list(self, tags_list):
        self.tags = json.dumps(tags_list)
    
    def get_average_rating(self):
        avg_rating = db.session.query(db.func.avg(ProductReview.rating)).filter(
            ProductReview.product_id == self.id
        ).scalar()
        return round(avg_rating, 1) if avg_rating else 0
    
    def to_dict(self):
        return {
            'id': self.id,
            'vendor_id': self.vendor_id,
            'name': self.name,
            'description': self.description,
            'short_description': self.short_description,
            'price': float(self.price),
            'currency': self.currency,
            'product_type': self.product_type.value,
            'category': self.category,
            'tags': self.get_tags_list(),
            'commission_percentage': float(self.commission_percentage),
            'status': self.status.value,
            'is_active': self.is_active,
            'is_featured': self.is_featured,
            'views_count': self.views_count,
            'sales_count': self.sales_count,
            'average_rating': self.get_average_rating(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# Affiliate Link Model
class AffiliateLink(db.Model):
    __tablename__ = 'affiliate_links'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    affiliate_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    product_id = db.Column(db.String(36), db.ForeignKey('products.id'), nullable=False)
    
    # Link details
    link_code = db.Column(db.String(50), unique=True, nullable=False)
    custom_url = db.Column(db.String(500), nullable=True)
    
    # Tracking
    clicks_count = db.Column(db.Integer, default=0)
    conversions_count = db.Column(db.Integer, default=0)
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    expires_at = db.Column(db.DateTime, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    affiliate = db.relationship('User', backref='affiliate_links')
    clicks = db.relationship('LinkClick', backref='affiliate_link', lazy=True)
    
    def generate_link_code(self):
        if not self.link_code:
            self.link_code = f"AFL{str(uuid.uuid4())[:12].upper()}"
    
    def get_conversion_rate(self):
        if self.clicks_count == 0:
            return 0
        return (self.conversions_count / self.clicks_count) * 100
    
    def to_dict(self):
        return {
            'id': self.id,
            'affiliate_id': self.affiliate_id,
            'product_id': self.product_id,
            'link_code': self.link_code,
            'custom_url': self.custom_url,
            'clicks_count': self.clicks_count,
            'conversions_count': self.conversions_count,
            'conversion_rate': self.get_conversion_rate(),
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# Transaction Model
class Transaction(db.Model):
    __tablename__ = 'transactions'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    product_id = db.Column(db.String(36), db.ForeignKey('products.id'), nullable=False)
    affiliate_link_id = db.Column(db.String(36), db.ForeignKey('affiliate_links.id'), nullable=True)
    
    # Transaction details
    transaction_ref = db.Column(db.String(100), unique=True, nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    currency = db.Column(db.String(3), default='NGN')
    
    # Payment details
    payment_method = db.Column(db.String(50), nullable=False)  # paystack, flutterwave, bank_transfer, etc.
    payment_ref = db.Column(db.String(200), nullable=True)
    gateway_response = db.Column(db.Text, nullable=True)  # JSON response from payment gateway
    
    # Status
    status = db.Column(db.Enum(TransactionStatus), default=TransactionStatus.PENDING)
    
    # Customer details
    customer_email = db.Column(db.String(120), nullable=False)
    customer_name = db.Column(db.String(100), nullable=False)
    customer_phone = db.Column(db.String(20), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    completed_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    commissions = db.relationship('Commission', backref='transaction', lazy=True)
    
    def generate_transaction_ref(self):
        if not self.transaction_ref:
            self.transaction_ref = f"TXN{str(uuid.uuid4())[:12].upper()}"
    
    def to_dict(self):
        return {
            'id': self.id,
            'transaction_ref': self.transaction_ref,
            'amount': float(self.amount),
            'currency': self.currency,
            'payment_method': self.payment_method,
            'status': self.status.value,
            'customer_email': self.customer_email,
            'customer_name': self.customer_name,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None
        }

# Commission Model
class Commission(db.Model):
    __tablename__ = 'commissions'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    transaction_id = db.Column(db.String(36), db.ForeignKey('transactions.id'), nullable=False)
    affiliate_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    
    # Commission details
    commission_type = db.Column(db.String(20), nullable=False)  # 'direct' or 'indirect'
    commission_level = db.Column(db.Integer, nullable=False)  # 1 for direct, 2 for indirect
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    percentage = db.Column(db.Numeric(5, 2), nullable=False)
    
    # Status
    status = db.Column(db.String(20), default='pending')  # pending, completed, cancelled
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    paid_at = db.Column(db.DateTime, nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'transaction_id': self.transaction_id,
            'affiliate_id': self.affiliate_id,
            'commission_type': self.commission_type,
            'commission_level': self.commission_level,
            'amount': float(self.amount),
            'percentage': float(self.percentage),
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'paid_at': self.paid_at.isoformat() if self.paid_at else None
        }

# Bank Account Model
class BankAccount(db.Model):
    __tablename__ = 'bank_accounts'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    
    # Bank details
    account_name = db.Column(db.String(100), nullable=False)
    account_number = db.Column(db.String(10), nullable=False)
    bank_name = db.Column(db.String(100), nullable=False)
    bank_code = db.Column(db.String(10), nullable=False)
    
    # Nigerian KYC requirements
    bvn = db.Column(db.String(11), nullable=False)
    nin = db.Column(db.String(11), nullable=True)
    
    # Status
    is_verified = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    verified_at = db.Column(db.DateTime, nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'account_name': self.account_name,
            'account_number': self.account_number,
            'bank_name': self.bank_name,
            'bank_code': self.bank_code,
            'is_verified': self.is_verified,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

# Withdrawal Model
class Withdrawal(db.Model):
    __tablename__ = 'withdrawals'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    bank_account_id = db.Column(db.String(36), db.ForeignKey('bank_accounts.id'), nullable=False)
    
    # Withdrawal details
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    currency = db.Column(db.String(3), default='NGN')
    reason = db.Column(db.Text, nullable=True)
    
    # Processing details
    reference = db.Column(db.String(100), unique=True, nullable=False)
    gateway_reference = db.Column(db.String(200), nullable=True)
    gateway_response = db.Column(db.Text, nullable=True)
    
    # Status
    status = db.Column(db.Enum(WithdrawalStatus), default=WithdrawalStatus.PENDING)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    processed_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    bank_account = db.relationship('BankAccount', backref='withdrawals')
    
    def generate_reference(self):
        if not self.reference:
            self.reference = f"WTH{str(uuid.uuid4())[:12].upper()}"
    
    def to_dict(self):
        return {
            'id': self.id,
            'amount': float(self.amount),
            'currency': self.currency,
            'reason': self.reason,
            'reference': self.reference,
            'status': self.status.value,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'bank_account': self.bank_account.to_dict() if self.bank_account else None
        }

# KYC Document Model
class KYCDocument(db.Model):
    __tablename__ = 'kyc_documents'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    
    # Document details
    document_type = db.Column(db.String(50), nullable=False)  # id_card, passport, utility_bill, etc.
    document_url = db.Column(db.String(500), nullable=False)
    document_number = db.Column(db.String(100), nullable=True)
    
    # Status
    status = db.Column(db.Enum(KYCStatus), default=KYCStatus.PENDING)
    admin_notes = db.Column(db.Text, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    reviewed_at = db.Column(db.DateTime, nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'document_type': self.document_type,
            'document_url': self.document_url,
            'status': self.status.value,
            'admin_notes': self.admin_notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None
        }

# Link Click Tracking Model
class LinkClick(db.Model):
    __tablename__ = 'link_clicks'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    affiliate_link_id = db.Column(db.String(36), db.ForeignKey('affiliate_links.id'), nullable=False)
    
    # Tracking details
    ip_address = db.Column(db.String(45), nullable=True)
    user_agent = db.Column(db.Text, nullable=True)
    referrer = db.Column(db.String(500), nullable=True)
    
    # Location data (optional)
    country = db.Column(db.String(100), nullable=True)
    city = db.Column(db.String(100), nullable=True)
    
    # Conversion tracking
    converted = db.Column(db.Boolean, default=False)
    conversion_value = db.Column(db.Numeric(10, 2), nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    converted_at = db.Column(db.DateTime, nullable=True)

# Product Review Model
class ProductReview(db.Model):
    __tablename__ = 'product_reviews'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    product_id = db.Column(db.String(36), db.ForeignKey('products.id'), nullable=False)
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    
    # Review details
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    title = db.Column(db.String(200), nullable=True)
    comment = db.Column(db.Text, nullable=True)
    
    # Status
    is_approved = db.Column(db.Boolean, default=False)
    is_verified_purchase = db.Column(db.Boolean, default=False)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    
    # Relationships
    reviewer = db.relationship('User', backref='reviews')
    
    def to_dict(self):
        return {
            'id': self.id,
            'rating': self.rating,
            'title': self.title,
            'comment': self.comment,
            'is_approved': self.is_approved,
            'is_verified_purchase': self.is_verified_purchase,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'reviewer': {
                'id': self.reviewer.id,
                'username': self.reviewer.username,
                'first_name': self.reviewer.first_name,
                'last_name': self.reviewer.last_name
            } if self.reviewer else None
        }

# Blog Post Model (for admin-managed content)
class BlogPost(db.Model):
    __tablename__ = 'blog_posts'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    author_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    
    # Post details
    title = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), unique=True, nullable=False)
    content = db.Column(db.Text, nullable=False)
    excerpt = db.Column(db.Text, nullable=True)
    
    # SEO
    meta_title = db.Column(db.String(200), nullable=True)
    meta_description = db.Column(db.String(500), nullable=True)
    
    # Status
    is_published = db.Column(db.Boolean, default=False)
    is_featured = db.Column(db.Boolean, default=False)
    
    # Categories and tags
    category = db.Column(db.String(100), nullable=True)
    tags = db.Column(db.Text, nullable=True)  # JSON array
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    published_at = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    author = db.relationship('User', backref='blog_posts')
    
    def get_tags_list(self):
        if self.tags:
            return json.loads(self.tags)
        return []
    
    def set_tags_list(self, tags_list):
        self.tags = json.dumps(tags_list)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'slug': self.slug,
            'content': self.content,
            'excerpt': self.excerpt,
            'is_published': self.is_published,
            'is_featured': self.is_featured,
            'category': self.category,
            'tags': self.get_tags_list(),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'published_at': self.published_at.isoformat() if self.published_at else None,
            'author': {
                'id': self.author.id,
                'username': self.author.username,
                'first_name': self.author.first_name,
                'last_name': self.author.last_name
            } if self.author else None
        }

