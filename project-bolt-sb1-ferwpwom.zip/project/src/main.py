import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from flask_cors import CORS
from src.models.user import db
from src.routes.auth import auth_bp
from src.routes.affiliate import affiliate_bp
from src.routes.payment import payment_bp
from src.routes.product import product_bp
from src.routes.admin import admin_bp
from src.routes.vendor import vendor_bp
from src.routes.user import user_bp
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'hisnak-marketplace-secret-key-2024')
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_pre_ping': True,
    'pool_recycle': 300,
}

# CORS configuration - Allow all origins for development
CORS(app, origins="*", allow_headers=["Content-Type", "Authorization"], methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])

# Initialize database
db.init_app(app)

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(affiliate_bp, url_prefix='/api/affiliate')
app.register_blueprint(payment_bp, url_prefix='/api/payment')
app.register_blueprint(product_bp, url_prefix='/api/products')
app.register_blueprint(admin_bp, url_prefix='/api/admin')
app.register_blueprint(vendor_bp, url_prefix='/api/vendor')
app.register_blueprint(user_bp, url_prefix='/api/user')

# Create database tables
with app.app_context():
    try:
        db.create_all()
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {str(e)}")

# Health check endpoint
@app.route('/api/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'service': 'Hisnak Marketplace Backend',
        'version': '1.0.0'
    })

# API documentation endpoint
@app.route('/api/docs')
def api_docs():
    return jsonify({
        'service': 'Hisnak Marketplace Backend API',
        'version': '1.0.0',
        'endpoints': {
            'authentication': '/api/auth/*',
            'affiliate': '/api/affiliate/*',
            'payment': '/api/payment/*',
            'products': '/api/products/*',
            'admin': '/api/admin/*',
            'vendor': '/api/vendor/*',
            'user': '/api/user/*'
        },
        'features': [
            'Multi-level affiliate commission tracking',
            'Payment gateway integration (Paystack, Flutterwave)',
            'KYC verification system',
            'Bank account management',
            'Automated payout system',
            'Product management',
            'Real-time notifications'
        ]
    })

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return jsonify({'error': 'Internal server error'}), 500

@app.errorhandler(400)
def bad_request(error):
    return jsonify({'error': 'Bad request'}), 400

@app.errorhandler(401)
def unauthorized(error):
    return jsonify({'error': 'Unauthorized'}), 401

@app.errorhandler(403)
def forbidden(error):
    return jsonify({'error': 'Forbidden'}), 403

# Serve static files (for frontend integration)
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return jsonify({'message': 'Hisnak Marketplace Backend API', 'status': 'running'}), 200

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return jsonify({'message': 'Hisnak Marketplace Backend API', 'status': 'running'}), 200

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    
    logger.info(f"Starting Hisnak Marketplace Backend on port {port}")
    app.run(host='0.0.0.0', port=port, debug=debug)

